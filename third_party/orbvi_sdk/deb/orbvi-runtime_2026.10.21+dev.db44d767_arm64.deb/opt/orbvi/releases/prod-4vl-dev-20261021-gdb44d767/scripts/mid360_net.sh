#!/usr/bin/env bash
set -euo pipefail

if [ -f /etc/default/orbvi ]; then
  set -a
  # shellcheck source=/etc/default/orbvi
  source /etc/default/orbvi
  set +a
fi

iface="${ORBVI_MID360_INTERFACE:-eth0}"
config_path="${ORBVI_MID360_CONFIG_PATH:-/var/lib/board-calib/MID360s_config.json}"
prefix="${ORBVI_MID360_PREFIX:-24}"

if [ ! -f "${config_path}" ]; then
  echo "Mid360 config missing: ${config_path}" >&2
  exit 1
fi

json_value() {
  local key="$1"
  python3 - "${config_path}" "${key}" <<'PY'
import json
import sys

path, key = sys.argv[1:3]
with open(path, "r", encoding="utf-8") as config_file:
    data = json.load(config_file)

host_net = data.get("Mid360s", {}).get("host_net_info", [{}])[0]
if key == "host_ip":
    print(host_net.get("host_ip", ""))
elif key == "lidar_ip":
    value = host_net.get("lidar_ip", "")
    if isinstance(value, list):
        print(value[0] if value else "")
    else:
        print(value)
PY
}

host_ip="${ORBVI_MID360_HOST_IP:-$(json_value host_ip)}"
mid360_ip="${ORBVI_MID360_IP:-$(json_value lidar_ip)}"

if [ -z "${host_ip}" ] || [ -z "${mid360_ip}" ]; then
  echo "Mid360 config must provide host_ip and lidar_ip: ${config_path}" >&2
  exit 1
fi
network="${mid360_ip%.*}.0/${prefix}"

ip link set "${iface}" up
ip addr replace "${host_ip}/${prefix}" dev "${iface}"
ip route replace "${network}" dev "${iface}" src "${host_ip}"
