#!/usr/bin/env bash
set -uo pipefail

if [ -f /etc/default/orbvi ]; then
  set -a
  # shellcheck source=/etc/default/orbvi
  source /etc/default/orbvi
  set +a
fi

source "$(dirname "${BASH_SOURCE[0]}")/release_layers.sh" || exit 1
if [ "${orbvi_release_bridge}" = ros1 ]; then
  set +u
  source "${ORBVI_ROS_SETUP:-/opt/ros/noetic/setup.bash}" >/dev/null 2>&1 || true
  source "${ORBVI_WS_SETUP:-/opt/orbvi/current/setup.bash}" >/dev/null 2>&1 || true
  set -u
else
  source "$(dirname "${BASH_SOURCE[0]}")/../setup.bash" || exit 1
fi

health_rostopic="${ORBVI_HEALTH_ROSTOPIC_BIN:-rostopic}"
status_file="${ORBVI_HEALTH_STATUS_FILE:-/data/orbvi/ota/health/latest.json}"
mkdir -p "$(dirname "${status_file}")"

overall_ok=true
calibration_unavailable=false
modules=()

json_escape() {
  local value="${1:-}"
  value="${value//\\/\\\\}"
  value="${value//\"/\\\"}"
  value="${value//$'\n'/\\n}"
  printf '%s' "${value}"
}

add_module() {
  local name="$1"
  local state="$2"
  local detail="${3:-}"
  local required="${4:-true}"
  if [ "${calibration_unavailable:-false}" = true ]; then
    case "${name}" in
      hsnet_input|hsnet|disparity|vins_config|vins|vins_native_process|vins_native_endpoint|vins_imu_propagate|vins_odometry|omni_livo|omni_livo_native_process|omni_livo_native_pose|omni_livo_native_cloud|omni_livo_odometry|omni_livo_cloud)
        state=blocked_calibration
        required=false
        detail="waiting for valid camera calibration"
        ;;
    esac
  fi
  modules+=("{\"name\":\"$(json_escape "${name}")\",\"state\":\"$(json_escape "${state}")\",\"required\":${required},\"detail\":\"$(json_escape "${detail}")\"}")
  if [ "${required}" = "true" ] && [ "${state}" != "ok" ] && [ "${state}" != "disabled" ]; then
    overall_ok=false
  fi
}

is_enabled() {
  [ "${1:-true}" = "true" ]
}

service_state() {
  local service="$1"
  systemctl is-active "${service}" 2>/dev/null || printf 'unknown'
}

check_service() {
  local name="$1"
  local service="$2"
  local enabled="${3:-true}"
  local required="${4:-true}"
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" "${service} disabled by config" "false"
    return
  fi
  if ! command -v systemctl >/dev/null 2>&1; then
    add_module "${name}" "failed" "${service} cannot be checked: systemctl unavailable" "${required}"
    return
  fi
  if systemctl is-active --quiet "${service}"; then
    add_module "${name}" "ok" "${service} active" "${required}"
  else
    add_module "${name}" "failed" "${service} $(service_state "${service}")" "${required}"
  fi
}

check_service_restart_count() {
  local name="$1"
  local service="$2"
  local enabled="${3:-true}"
  local required="${4:-true}"
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" \
      "${service} restart-count check disabled by config" "false"
    return
  fi
  if ! command -v systemctl >/dev/null 2>&1; then
    add_module "${name}" "failed" \
      "${service} restart count cannot be checked: systemctl unavailable" \
      "${required}"
    return
  fi

  local restart_count
  if ! restart_count="$(systemctl show --property=NRestarts --value \
      "${service}" 2>/dev/null)" ||
     ! [[ "${restart_count}" =~ ^[0-9]+$ ]]; then
    add_module "${name}" "failed" \
      "${service} restart count is unavailable" "${required}"
  elif [ "${restart_count}" -eq 0 ]; then
    add_module "${name}" "ok" \
      "${service} has not auto-restarted" "${required}"
  else
    add_module "${name}" "failed" \
      "${service} auto-restarted ${restart_count} time(s)" "${required}"
  fi
}

check_service_inactive() {
  local name="$1"
  local service="$2"
  local enabled="${3:-true}"
  local required="${4:-true}"
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" \
      "${service} inactivity check disabled by product profile" "false"
    return
  fi
  if ! command -v systemctl >/dev/null 2>&1; then
    add_module "${name}" "failed" \
      "${service} cannot be checked: systemctl unavailable" "${required}"
    return
  fi
  if systemctl is-active --quiet "${service}"; then
    add_module "${name}" "failed" \
      "${service} active but forbidden by product profile" "${required}"
  else
    add_module "${name}" "ok" \
      "${service} inactive as required by product profile" "${required}"
  fi
}

check_service_executable() {
  local name="$1"
  local service="$2"
  local expected_executable="$3"
  local enabled="${4:-true}"
  local required="${5:-true}"
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" \
      "${service} executable check disabled by config" "false"
    return
  fi
  if ! command -v systemctl >/dev/null 2>&1 ||
     ! command -v readlink >/dev/null 2>&1; then
    add_module "${name}" "failed" \
      "${service} executable cannot be checked" "${required}"
    return
  fi

  local main_pid executable
  if ! main_pid="$(systemctl show --property=MainPID --value "${service}" 2>/dev/null)" ||
     ! [[ "${main_pid}" =~ ^[1-9][0-9]*$ ]] ||
     ! executable="$(readlink -f "/proc/${main_pid}/exe" 2>/dev/null)"; then
    add_module "${name}" "failed" \
      "${service} has no inspectable main process" "${required}"
    return
  fi
  if [ "${executable##*/}" = "${expected_executable}" ]; then
    add_module "${name}" "ok" \
      "${service} owns ${executable}" "${required}"
  else
    add_module "${name}" "failed" \
      "${service} owns ${executable}; expected ${expected_executable}" "${required}"
  fi
}

check_file() {
  local name="$1"
  local path="$2"
  local enabled="${3:-true}"
  local required="${4:-true}"
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" "${path} disabled by config" "false"
    return
  fi
  if [ -f "${path}" ]; then
    add_module "${name}" "ok" "${path} exists" "${required}"
  else
    add_module "${name}" "missing" "${path} missing" "${required}"
  fi
}

check_socket() {
  local name="$1"
  local path="$2"
  local enabled="${3:-true}"
  local required="${4:-true}"
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" "${path} disabled by config" "false"
    return
  fi
  if [ -S "${path}" ]; then
    add_module "${name}" "ok" "${path} is a Unix socket" "${required}"
  else
    add_module "${name}" "missing" "${path} socket missing" "${required}"
  fi
}

check_ipc_endpoint() {
  local name="$1" endpoint="$2" enabled="$3" required="$4"
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" "native endpoint disabled by config" "false"
  elif [[ "${endpoint}" = ipc:///* ]]; then
    check_socket "${name}" "${endpoint#ipc://}" true "${required}"
  else
    add_module "${name}" "failed" "expected local IPC endpoint: ${endpoint}" "${required}"
  fi
}

topic_has_publisher() {
  local topic="$1"
  command -v "${health_rostopic}" >/dev/null 2>&1 || return 2
  timeout 5 "${health_rostopic}" info "${topic}" 2>/dev/null |
    awk '
      /^Publishers:/ { in_publishers=1; next }
      /^Subscribers:/ { in_publishers=0 }
      in_publishers && /\* / { found=1 }
      END { exit found ? 0 : 1 }
    '
}

topic_publisher_count() {
  local topic="$1"
  local topic_list
  if ! topic_list="$(timeout 5 "${health_rostopic}" list 2>/dev/null)"; then
    return 1
  fi
  if ! awk -v wanted="${topic}" '
    $0 == wanted { found=1 }
    END { exit found ? 0 : 1 }
  ' <<< "${topic_list}"; then
    printf '0\n'
    return 0
  fi

  local info
  if ! info="$(timeout 5 "${health_rostopic}" info "${topic}" 2>/dev/null)"; then
    return 1
  fi
  awk '
    /^Publishers:/ { in_publishers=1; next }
    /^Subscribers:/ { in_publishers=0 }
    in_publishers && /\* / { count++ }
    END { print count + 0 }
  ' <<< "${info}"
}

check_topic_publisher_count() {
  local name="$1"
  local topic="$2"
  local expected_count="$3"
  local enabled="${4:-true}"
  local required="${5:-true}"
  if [ "${orbvi_release_bridge}" != ros1 ]; then
    add_module "${name}" "disabled" "ROS1 probe not selected by release" "false"
    return
  fi
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" \
      "${topic} publisher count check disabled" "false"
    return
  fi
  if ! command -v "${health_rostopic}" >/dev/null 2>&1 ||
     ! command -v timeout >/dev/null 2>&1; then
    add_module "${name}" "failed" \
      "${topic} publisher count unavailable" "${required}"
    return
  fi
  local count
  if ! count="$(topic_publisher_count "${topic}")"; then
    add_module "${name}" "failed" \
      "${topic} publisher count query failed" "${required}"
    return
  fi
  if [ "${count}" = "${expected_count}" ]; then
    add_module "${name}" "ok" \
      "${topic} has expected publisher count ${expected_count}" "${required}"
  else
    add_module "${name}" "failed" \
      "${topic} expected ${expected_count} publisher(s), observed ${count}" \
      "${required}"
  fi
}

check_topic() {
  local name="$1"
  local topic="$2"
  local enabled="${3:-true}"
  local required="${4:-true}"
  if [ "${orbvi_release_bridge}" != ros1 ]; then
    add_module "${name}" "disabled" "ROS1 probe not selected by release" "false"
    return
  fi
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" "${topic} disabled by config" "false"
    return
  fi
  if topic_has_publisher "${topic}"; then
    add_module "${name}" "ok" "${topic} has publisher" "${required}"
  else
    add_module "${name}" "missing" "${topic} has no publisher" "${required}"
  fi
}

check_topic_message() {
  local name="$1"
  local topic="$2"
  local enabled="${3:-true}"
  local required="${4:-true}"
  local timeout_sec="${ORBVI_HEALTH_TOPIC_MESSAGE_TIMEOUT_SEC:-8}"
  if [ "${orbvi_release_bridge}" != ros1 ]; then
    add_module "${name}" "disabled" "ROS1 probe not selected by release" "false"
    return
  fi
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" "${topic} disabled by config" "false"
    return
  fi
  if ! command -v "${health_rostopic}" >/dev/null 2>&1 ||
     ! command -v timeout >/dev/null 2>&1; then
    add_module "${name}" "failed" \
      "${topic} cannot be sampled: rostopic/timeout unavailable" "${required}"
    return
  fi
  # The subscriber created by rostopic echo wakes lazy MPP/RGA conversion, so
  # this proves a payload was emitted instead of only observing an advertised
  # topic.
  if timeout "${timeout_sec}" "${health_rostopic}" echo -n 1 "${topic}" >/dev/null 2>&1; then
    add_module "${name}" "ok" "${topic} delivered a message" "${required}"
  else
    add_module "${name}" "missing" \
      "${topic} delivered no message within ${timeout_sec}s" "${required}"
  fi
}

check_realtime_stamped_topic_message() {
  local name="$1"
  local topic="$2"
  local enabled="${3:-true}"
  local required="${4:-true}"
  if [ "${orbvi_release_bridge}" != ros1 ]; then
    add_module "${name}" "disabled" "ROS1 probe not selected by release" "false"
    return
  fi
  local timeout_sec="${ORBVI_HEALTH_TOPIC_MESSAGE_TIMEOUT_SEC:-8}"
  local max_age_ms="${ORBVI_HEALTH_SOURCE_STAMP_MAX_AGE_MS:-3000}"
  local future_tolerance_ms="${ORBVI_HEALTH_SOURCE_STAMP_FUTURE_TOLERANCE_MS:-1000}"
  if ! is_enabled "${enabled}"; then
    add_module "${name}" "disabled" "${topic} disabled by config" "false"
    return
  fi
  if ! command -v "${health_rostopic}" >/dev/null 2>&1 ||
     ! command -v timeout >/dev/null 2>&1; then
    add_module "${name}" "failed" \
      "${topic} cannot be sampled: rostopic/timeout unavailable" "${required}"
    return
  fi
  if [[ ! "${max_age_ms}" =~ ^[0-9]+$ ]] ||
     [[ ! "${future_tolerance_ms}" =~ ^[0-9]+$ ]] ||
     [ "${max_age_ms}" -gt 3600000 ] ||
     [ "${future_tolerance_ms}" -gt 60000 ]; then
    add_module "${name}" "failed" \
      "invalid source timestamp freshness configuration" "${required}"
    return
  fi

  local stamp
  if ! stamp="$(timeout "${timeout_sec}" "${health_rostopic}" echo -n 1 \
      "${topic}/header/stamp" 2>/dev/null)"; then
    add_module "${name}" "missing" \
      "${topic} delivered no stamped message within ${timeout_sec}s" "${required}"
    return
  fi
  local stamp_secs stamp_nsecs
  stamp_secs="$(awk '$1 == "secs:" { print $2; exit }' <<< "${stamp}")"
  stamp_nsecs="$(awk '$1 == "nsecs:" { print $2; exit }' <<< "${stamp}")"
  if [[ ! "${stamp_secs}" =~ ^[0-9]+$ ]] ||
     [[ ! "${stamp_nsecs}" =~ ^[0-9]+$ ]] ||
     [ "${stamp_secs}" -gt 4294967295 ] ||
     [ "${stamp_nsecs}" -ge 1000000000 ] ||
     { [ "${stamp_secs}" -eq 0 ] && [ "${stamp_nsecs}" -eq 0 ]; }; then
    add_module "${name}" "failed" \
      "${topic} source timestamp is invalid" "${required}"
    return
  fi

  local now_ns stamp_ns age_ns max_age_ns future_tolerance_ns
  now_ns="$(date +%s%N)"
  if [[ ! "${now_ns}" =~ ^[0-9]+$ ]]; then
    add_module "${name}" "failed" \
      "CLOCK_REALTIME nanoseconds are unavailable" "${required}"
    return
  fi
  stamp_ns=$((10#${stamp_secs} * 1000000000 + 10#${stamp_nsecs}))
  age_ns=$((10#${now_ns} - stamp_ns))
  max_age_ns=$((10#${max_age_ms} * 1000000))
  future_tolerance_ns=$((10#${future_tolerance_ms} * 1000000))
  if [ "${age_ns}" -gt "${max_age_ns}" ]; then
    add_module "${name}" "failed" \
      "${topic} source timestamp is stale (${age_ns}ns old)" "${required}"
  elif [ "${age_ns}" -lt "$((-future_tolerance_ns))" ]; then
    add_module "${name}" "failed" \
      "${topic} source timestamp is too far in the future (${age_ns}ns age)" \
      "${required}"
  else
    add_module "${name}" "ok" \
      "${topic} delivered a fresh realtime-stamped message (${age_ns}ns old)" \
      "${required}"
  fi
}

check_http() {
  local name="$1"
  local url="$2"
  local retries="${ORBVI_HEALTH_HTTP_RETRIES:-15}"
  local interval="${ORBVI_HEALTH_HTTP_INTERVAL_SEC:-2}"
  local timeout_sec="${ORBVI_HEALTH_HTTP_TIMEOUT_SEC:-2}"
  local attempt
  for ((attempt = 1; attempt <= retries; attempt++)); do
    if curl -fsS --max-time "${timeout_sec}" "${url}" >/dev/null 2>&1; then
      add_module "${name}" "ok" "${url} reachable after ${attempt} attempt(s)" "true"
      return
    fi
    [ "${attempt}" -lt "${retries}" ] && sleep "${interval}"
  done
  add_module "${name}" "failed" "${url} unreachable after ${retries} attempt(s)" "true"
}

check_data_probe() {
  local name="$1" binary="$2" bridge="$3" detail profile
  if [ "${is_4v_product}" = true ]; then
    profile=production-4v
  elif [ "${is_4vl_product}" = true ]; then
    profile=production-4vl
  else
    add_module "${name}" "unverified" "bounded data acceptance requires a complete 4V/4VL product identity; OTA activation is blocked" true
    return
  fi
  if [ ! -x "${binary}" ] || ! command -v timeout >/dev/null 2>&1; then
    add_module "${name}" "failed" "required data probe or timeout utility missing: ${binary}" true
    return
  fi
  local -a command=("${binary}" --profile "${profile}")
  if [ "${bridge}" = ros2 ]; then
    local dds_profile="${runtime_root}/ros2/share/orbvi_ros2_adapter/config/fastdds.xml"
    if [ ! -f "${dds_profile}" ]; then
      add_module "${name}" "failed" "required ROS2 health transport profile missing: ${dds_profile}" true
      return
    fi
    command=(runuser -u orbvi -g orbvi -- env "FASTRTPS_DEFAULT_PROFILES_FILE=${dds_profile}" \
      RMW_IMPLEMENTATION=rmw_fastrtps_cpp ROS_LOG_DIR=/data/orbvi/logs/ros2 \
      /bin/bash -c 'set -e; source "$1"; source "$2"; exec "$3" --profile "$4" "${@:5}"' \
      _ /opt/ros/humble/setup.bash "${runtime_root}/ros2/setup.bash" "${binary}" "${profile}")
  fi
  # Include setup, connection, receive and cleanup in one hard wall-clock
  # bound. A killed/hung/missing probe never authorizes OTA commit/pruning.
  if [ "${calibration_unavailable:-false}" = true ]; then command+=(--uncalibrated); fi
  if detail="$(timeout --kill-after=2s 18s "${command[@]}" 2>&1)"; then
    add_module "${name}" "ok" "${detail:0:2048}" true
  else
    add_module "${name}" "failed" "${detail:0:2048}" true
  fi
}

if [ "${orbvi_release_bridge}" = ros1 ]; then
  check_service "roscore" "orbvi_roscore.service" "true" "true"
elif [ "${orbvi_release_bridge}" = ros2 ]; then
  check_service "ros2_adapter" "orbvi_ros2_adapter.service" "true" "true"
fi
check_service "sdk_server" "orbvi_sdk_server.service" "true" "true"
check_http "sdk_server_http" "http://127.0.0.1:${ORBVI_CONTROL_PORT:-18088}/v1/device/status"

# Keep acquisition gates mandatory while a device awaits calibration. A query
# failure is not evidence of missing calibration and must not relax any gate.
calibration_report="$(curl -fsS --max-time 3 "http://127.0.0.1:${ORBVI_CONTROL_PORT:-18088}/v1/calibration" 2>/dev/null || true)"
if [[ "${calibration_report}" == *'"status":"BLOCKED_CALIBRATION_MISSING"'* ]] &&
   [[ "${calibration_report}" != *'"calibration_hash_status":"RESTART_REQUIRED"'* ]]; then
  calibration_unavailable=true
fi

check_service "timesync_native" "orbvi_timesync.service" "${ORBVI_ENABLE_TIMESYNC:-true}" "true"
check_topic "timesync_imu" "/timesync/imu/data" "${ORBVI_ENABLE_TIMESYNC:-true}" "false"
if [ "${orbvi_release_bridge}" != ros1 ]; then
  check_ipc_endpoint "timesync_health_endpoint" "${ORBVI_TIMESYNC_HEALTH_ENDPOINT:-ipc:///run/orbvi/timing_health.ipc}" \
    "${ORBVI_ENABLE_TIMESYNC:-true}" true
  check_ipc_endpoint "timesync_imu_endpoint" "${ORBVI_TIMESYNC_IMU_ENDPOINT:-ipc:///run/orbvi/imu.ipc}" \
    "${ORBVI_ENABLE_TIMESYNC:-true}" true
  check_ipc_endpoint "timesync_trigger_endpoint" "${ORBVI_TIMESYNC_TRIGGER_ENDPOINT:-ipc:///run/orbvi/trigger_anchor.ipc}" \
    "${ORBVI_ENABLE_TIMESYNC:-true}" true
  check_ipc_endpoint "camera_native_endpoint" "${ORBVI_CAMERA_SYNC_ENDPOINT:-ipc:///run/orbvi/camera_sync.ipc}" true true
fi

rectify_enabled=true
camera_config_path="${ORBVI_CAMERA_CONFIG:-/var/lib/board-calib/camera_config.yaml}"
camera_group_sync_topic="/rk_cam/sync_info"
camera_group_sync_frame_sync_topic="/rk_cam/frame_sync_v2"
hsnet_enabled=false
hsnet_mode="${ORBVI_HSNET_MODE:-disabled}"
hsnet_model_path="${ORBVI_HSNET_MODEL_PATH:-/opt/orbvi/current/share/hsnet_disparity/models/hsnet_96.crypt.rknn}"
hsnet_disparity_topic="${ORBVI_HSNET_DISPARITY_TOPIC:-/disparity/raw}"
rectified_atlas_enabled=false
rectified_atlas_socket_path="/run/orbvi/rectified_atlas.sock"
vins_enabled=false
vins_config_path=""
runtime_root="${ORBVI_HEALTH_RUNTIME_ROOT:-/opt/orbvi/current}"
config_tool="${runtime_root}/lib/orbvi_camera_pipeline_runtime/camera_pipeline_configctl"
ros_config_tool="${runtime_root}/lib/orbvi_ros_adapter/orbvi_ros_adapter_node"
camera_pipeline_config_path="${ORBVI_CAMERA_PIPELINE_CONFIG:-/opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588.yaml}"
validate_ros1_config() {
  [ "${orbvi_release_bridge}" = ros1 ] || return 0
  [ -x "${ros_config_tool}" ] || return 1
  timeout "${ORBVI_HEALTH_TOPIC_TIMEOUT_SEC:-10}" "${ros_config_tool}" \
     __name:=orbvi_ros_adapter_config_validator \
     _camera_sync_endpoint:="${ORBVI_CAMERA_SYNC_ENDPOINT:-ipc:///run/orbvi/camera_sync.ipc}" \
     _camera_sync_topic:="${ORBVI_CAMERA_SYNC_TOPIC:-orbvi.v1.camera.frame_sync_v2}" \
     _camera_sync_reconnect_ms:="${ORBVI_CAMERA_SYNC_RECONNECT_MS:-200}" \
     _livox_source_enabled:="${ORBVI_LIVOX_ROS_SOURCE_ENABLED:-true}" \
     _livox_frame_socket:="${ORBVI_LIVOX_FRAME_SOCKET:-/run/orbvi/livox_frames.sock}" \
     _livox_pointcloud_topic:="${ORBVI_LIVOX_POINTCLOUD_TOPIC:-/livox/lidar}" \
     _livox_imu_topic:="${ORBVI_LIVOX_IMU_TOPIC:-/livox/imu}" \
     _livox_ros_queue_depth:="${ORBVI_LIVOX_ROS_QUEUE_DEPTH:-4}" \
     _livox_max_frame_bytes:="${ORBVI_LIVOX_MAX_FRAME_BYTES:-68157440}" \
     _livox_reconnect_ms:="${ORBVI_LIVOX_RECONNECT_MS:-500}" \
     _validate_only:=true >/dev/null 2>&1
}
if [ ! -x "${config_tool}" ] ||
   ! "${config_tool}" --config "${camera_pipeline_config_path}" --validate >/dev/null 2>&1 ||
   ! validate_ros1_config; then
  add_module "camera_pipeline_config" "failed" \
    "${camera_pipeline_config_path} failed native runtime or ROS adapter validation" "true"
  rectify_enabled=false
  rectified_atlas_enabled=false
  vins_enabled=false
else
  add_module "camera_pipeline_config" "ok" \
    "${camera_pipeline_config_path} is the active native Camera YAML" "true"
  pipeline_get() {
    "${config_tool}" --config "${camera_pipeline_config_path}" --get "$1"
  }
  rectify_enabled="$(pipeline_get fisheye.enabled)"
  camera_config_path="$(pipeline_get fisheye.calibration_path)"
  rectified_atlas_enabled="$(pipeline_get outputs.rectified_atlas_dmabuf.enabled)"
  rectified_atlas_socket_path="$(pipeline_get outputs.rectified_atlas_dmabuf.socket_path)"
  vins_enabled="$(pipeline_get vins.enabled)"
  vins_config_path="$(pipeline_get vins.config_path)"
fi
check_service "camera_native_owner" \
  "orbvi_camera_pipeline_native.service" "true" "true"
if [ "${orbvi_release_bridge}" = ros1 ]; then
  check_service "ros_adapter" "orbvi_ros_adapter.service" "true" "true"
fi
check_topic_publisher_count "camera_group_sync_owner" \
  "${camera_group_sync_topic}" "1" "true" "true"
check_topic_message "camera_group_sync" \
  "${camera_group_sync_topic}" "true" "true"
check_topic_publisher_count "camera_group_sync_frame_sync_owner" \
  "${camera_group_sync_frame_sync_topic}" "1" "true" "true"
check_topic_message "camera_group_sync_frame_sync" \
  "${camera_group_sync_frame_sync_topic}" "true" "true"
check_topic_publisher_count "camera_group_sync_deprecated_topic" \
  "/stereo/sync_info" "0" "true" "true"
check_file "camera_config" "${camera_config_path}" "${rectify_enabled}" "false"

case "${hsnet_mode}" in
  dmabuf)
    hsnet_enabled=true
    add_module "hsnet_owner" "ok" \
      "ROS-free HSNet runtime owns inference; unified ROS adapter owns ${hsnet_disparity_topic}" "false"
    if ! is_enabled "${rectified_atlas_enabled}"; then
      add_module "hsnet_input" "failed" \
        "Camera rectified-atlas output is disabled" "true"
    else
      add_module "hsnet_input" "ok" \
        "generic rectified-atlas socket ${rectified_atlas_socket_path}" "false"
    fi
    check_service "hsnet" "orbvi_hsnet_disparity.service" "true" "false"
    ;;
  disabled)
    hsnet_enabled=false
    add_module "hsnet_owner" "disabled" "HSNet disabled by config" "false"
    check_service "hsnet" "orbvi_hsnet_disparity.service" "false" "false"
    ;;
  *)
    hsnet_enabled=false
    add_module "hsnet_owner" "failed" \
      "invalid ORBVI_HSNET_MODE=${hsnet_mode}; expected dmabuf or disabled" \
      "true"
    ;;
esac
check_file "hsnet_model" "${hsnet_model_path}" "${hsnet_enabled}" "false"
check_realtime_stamped_topic_message \
  "disparity" "${hsnet_disparity_topic}" "${hsnet_enabled}" "false"

is_4v_product=false
is_4vl_product=false
if [ "${ORBVI_RELEASE_PROFILE:-}" = "production-4v" ] &&
   [ "${ORBVI_PRODUCT:-}" = "orbvi" ] &&
   [ "${ORBVI_DEVICE_MODEL:-}" = "orbvi-4v" ] &&
   [ "${ORBVI_HARDWARE_PROFILE:-}" = "4v" ]; then
  is_4v_product=true
elif [ "${ORBVI_RELEASE_PROFILE:-}" = "production-4vl" ] &&
     [ "${ORBVI_PRODUCT:-}" = "orbvi" ] &&
     [ "${ORBVI_DEVICE_MODEL:-}" = "orbvi-4vl" ] &&
     [ "${ORBVI_HARDWARE_PROFILE:-}" = "4vl" ]; then
  is_4vl_product=true
fi

if [ "${is_4v_product}" = "true" ] && ! is_enabled "${vins_enabled}"; then
  add_module "localization_profile" "failed" \
    "production-4v requires vins.enabled=true" "true"
elif [ "${is_4vl_product}" = "true" ] && is_enabled "${vins_enabled}"; then
  add_module "localization_profile" "failed" \
    "production-4vl requires vins.enabled=false" "true"
elif [ "${is_4v_product}" = "true" ]; then
  add_module "localization_profile" "ok" \
    "production-4v selects VINS" "true"
elif [ "${is_4vl_product}" = "true" ]; then
  add_module "localization_profile" "ok" \
    "production-4vl selects Omni-LIVO" "true"
fi

check_file "vins_config" "${vins_config_path}" "${vins_enabled}" "${is_4v_product}"
check_service "vins" "orbvi_vins.service" "${vins_enabled}" "${is_4v_product}"
check_service_executable "vins_native_process" "orbvi_vins.service" "vins_native_node" \
  "${vins_enabled}" "${is_4v_product}"
if [ "${orbvi_release_bridge}" != ros1 ]; then
  check_ipc_endpoint "vins_native_endpoint" "${ORBVI_VINS_MSGBUS_ENDPOINT:-ipc:///run/orbvi/vins_pose.ipc}" \
    "${vins_enabled}" "${is_4v_product}"
fi
check_topic "vins_imu_propagate" "${ORBVI_VIO_PROPAGATE_TOPIC:-/orbvi/imu_propagate}" "${vins_enabled}" "${is_4v_product}"
check_topic "vins_odometry" "${ORBVI_VIO_OPTIMIZED_TOPIC:-/orbvi/odometry}" "${vins_enabled}" "${is_4v_product}"
check_service_inactive "vins_forbidden_on_4vl" \
  "orbvi_vins.service" "${is_4vl_product}" "${is_4vl_product}"

check_file "omni_livo_algorithm_profile" \
  "${runtime_root}/share/omni_livo/config/mid360_native.yaml" \
  "${is_4vl_product}" "${is_4vl_product}"
check_file "omni_livo_camera_calibration" \
  "${ORBVI_CALIBRATION_PATH:-/var/lib/board-calib/camera_config.yaml}" \
  "${is_4vl_product}" "${is_4vl_product}"
check_file "omni_livo_front_anchor" \
  "${ORBVI_LIDAR_CALIBRATION_PATH:-/var/lib/board-calib/MID360s_Calibration}/cam0_multi_calib_result.txt" \
  "${is_4vl_product}" "${is_4vl_product}"
check_file "omni_livo_lidar_imu_calibration" \
  "${ORBVI_LIDAR_CALIBRATION_PATH:-/var/lib/board-calib/MID360s_Calibration}/lidar_imu.json" \
  "${is_4vl_product}" "${is_4vl_product}"
check_service "omni_livo" "orbvi_omni_livo.service" "${is_4vl_product}" "${is_4vl_product}"
check_service_executable "omni_livo_native_process" \
  "orbvi_omni_livo.service" "omni_livo_native_node" \
  "${is_4vl_product}" "${is_4vl_product}"
check_socket "omni_livo_native_pose" \
  "${ORBVI_OMNI_LIVO_POSE_SOCKET:-/run/orbvi/omni_livo_pose.ipc}" \
  "${is_4vl_product}" "${is_4vl_product}"
check_socket "omni_livo_native_cloud" \
  "${ORBVI_OMNI_LIVO_CLOUD_SOCKET:-/run/orbvi/omni_livo_registered_cloud.sock}" \
  "${is_4vl_product}" "${is_4vl_product}"
check_topic_message "omni_livo_odometry" "/aft_mapped_to_init" "${is_4vl_product}" "${is_4vl_product}"
check_topic_message "omni_livo_cloud" "/cloud_registered" "${is_4vl_product}" "${is_4vl_product}"
check_service_restart_count "omni_livo_restart_count" \
  "orbvi_omni_livo.service" "${is_4vl_product}" "${is_4vl_product}"
check_service_inactive "omni_livo_forbidden_on_4v" \
  "orbvi_omni_livo.service" "${is_4v_product}" "${is_4v_product}"

livox_required=false
if [ "${ORBVI_RELEASE_PROFILE:-}" = "production-4vl" ] &&
   [ "${ORBVI_PRODUCT:-}" = "orbvi" ] &&
   [ "${ORBVI_DEVICE_MODEL:-}" = "orbvi-4vl" ] &&
   [ "${ORBVI_HARDWARE_PROFILE:-}" = "4vl" ] &&
   [ "${ORBVI_ENABLE_LIVOX:-true}" = "true" ]; then
  livox_required=true
fi
check_file "mid360_config" "${ORBVI_MID360_CONFIG_PATH:-/var/lib/board-calib/MID360s_config.json}" "${ORBVI_ENABLE_LIVOX:-true}" "${livox_required}"
check_service "mid360_net" "orbvi_mid360_net.service" "${ORBVI_ENABLE_LIVOX:-true}" "${livox_required}"
check_service "mid360_ptp" "orbvi_mid360_ptp.service" "${ORBVI_ENABLE_LIVOX:-true}" "${livox_required}"
check_service "mid360_phc2sys" "orbvi_mid360_phc2sys.service" "${ORBVI_ENABLE_LIVOX:-true}" "${livox_required}"
check_service "mid360" "orbvi_mid360.service" "${ORBVI_ENABLE_LIVOX:-true}" "${livox_required}"
check_socket "livox_native_frames" \
  "${ORBVI_LIVOX_FRAME_SOCKET:-/run/orbvi/livox_frames.sock}" \
  "${ORBVI_ENABLE_LIVOX:-true}" "${livox_required}"
livox_ros_enabled=false
livox_ros_required=false
if [ "${ORBVI_ENABLE_LIVOX:-true}" = "true" ] &&
   [ "${ORBVI_LIVOX_ROS_SOURCE_ENABLED:-true}" = "true" ]; then
  livox_ros_enabled=true
  livox_ros_required="${livox_required}"
fi
check_topic_publisher_count "livox_pointcloud_owner" \
  "${ORBVI_LIVOX_POINTCLOUD_TOPIC:-/livox/lidar}" "1" \
  "${livox_ros_enabled}" "${livox_ros_required}"
check_topic_message "livox_pointcloud" \
  "${ORBVI_LIVOX_POINTCLOUD_TOPIC:-/livox/lidar}" \
  "${livox_ros_enabled}" "${livox_ros_required}"
check_topic_publisher_count "livox_imu_owner" \
  "${ORBVI_LIVOX_IMU_TOPIC:-/livox/imu}" "1" \
  "${livox_ros_enabled}" "${livox_ros_required}"
check_topic_message "livox_imu" \
  "${ORBVI_LIVOX_IMU_TOPIC:-/livox/imu}" \
  "${livox_ros_enabled}" "${livox_ros_required}"

if [ "${orbvi_release_bridge}" != ros1 ]; then
  check_data_probe native_data "${runtime_root}/lib/orbvi_health/orbvi_native_health_probe" native
  if [ "${orbvi_release_bridge}" = ros2 ]; then
    check_data_probe ros2_data "${runtime_root}/ros2/lib/orbvi_ros2_adapter/orbvi_ros2_health_probe" ros2
  fi
fi

check_file "calibration" "${ORBVI_CALIBRATION_PATH:-/var/lib/board-calib/camera_config.yaml}" "true" "false"

add_module "readiness_scope" "ok" "$([ "${calibration_unavailable:-false}" = true ] && printf capture || printf full)" false

tmp="${status_file}.$$"
{
  printf '{"ok":%s,"generated_at":"%s","modules":[' \
    "$([ "${overall_ok}" = "true" ] && printf true || printf false)" \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  for i in "${!modules[@]}"; do
    [ "${i}" = "0" ] || printf ','
    printf '%s' "${modules[$i]}"
  done
  printf ']}\n'
} > "${tmp}"
mv "${tmp}" "${status_file}"
cat "${status_file}"

[ "${overall_ok}" = "true" ]
