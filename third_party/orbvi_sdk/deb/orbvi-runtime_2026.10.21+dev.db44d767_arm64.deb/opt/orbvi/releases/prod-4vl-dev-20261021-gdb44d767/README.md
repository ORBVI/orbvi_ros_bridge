# ORBVI production runtime

This directory is the installed ARM64 runtime for RK3588 ORBVI 4V/4VL.
The selected product profile and defaults are in `etc/default/orbvi`.
Production services run the native daemons under `lib/<component>/`;
ROS1, when included, is a bridge and can be loaded with `source setup.bash`.

## Release layers

The bridge selection is recorded in `scripts/release_bridge`. It is a package
composition choice, independent of the 4V/4VL product profile. Site defaults
do not provide a bridge-mode switch.

| Selection | Runtime files | Environment | Bridge units |
| --- | --- | --- | --- |
| `ros1` (default) | Shared native runtime plus ROS1 adapter/messages | `setup.bash` from composed catkin tree | roscore and ROS1 adapter |
| `none` | Shared native runtime | Native `setup.bash`, no ROS sourcing | None |
| `ros2` (bundle builder) | Shared native runtime plus separate `ros2/` colcon tree and ABI closure | Native `setup.bash`; source Humble and `ros2/setup.bash` explicitly for ROS2 tools | ROS2 adapter |

`scripts/package/rk3588-runtime.rsync-filter` defines shared native membership;
`rk3588-ros1.rsync-filter` adds the optional ROS1 overlay before that filter.
Known ROS1 adapter libraries (including SONAME variants) are excluded from
native-only and ROS2 payloads. Other shared libraries are retained conservatively;
native payload ELF validation rejects unresolved symbols/dependencies and ROS
linkage. Development exports remain available in the original install tree.
For non-ROS1 4V packages, the optional 4VL Omni-LIVO executable is excluded at
this shared payload boundary, rather than removed again by the deb builder.

Build examples, from the repository in Docker:

```bash
# Existing default: ROS1 interfaces remain enabled.
scripts/assemble-install.sh
scripts/orbvi_build_factory_deb.sh --install-dir install/combined/rk3588 \
  --profile production-4v

# Explicit native-only package; ROS1 does not need to have been built.
scripts/assemble-install.sh --bridge none
scripts/orbvi_build_factory_deb.sh --install-dir install/combined/rk3588-native \
  --profile production-4v --bridge none
scripts/orbvi_make_release_payload.sh --install-dir install/native/rk3588 \
  --profile production-4v --bridge none --output /tmp/native-payload.tar

# ROS2 adds its own overlay to the shared native payload.
scripts/orbvi_build_ros2_factory_bundle.sh \
  --native-install-dir install/native/rk3588 \
  --ros2-install-dir install/ros2/rk3588 \
  --native-runtime-lib-dir /path/to/validated-focal-abi-closure \
  --profile production-4v --output /tmp/ros2-factory.tar.gz
```

The payload builder's `--bridge ros2` is an intermediate for the bundle builder,
not a standalone ROS2 OTA artifact: the colcon overlay and ABI closure must
still be supplied by the bundle builder. The existing ROS2 deb wrapper still
accepts only `production-4v`; this change does not broaden that release gate.

`scripts/release_layers.sh` is the common source for release and boot service
membership. Activation restarts the native Camera owner before its selected
bridge. Native units do not acquire a reverse dependency on ROS. Native-only
factory dependencies omit Noetic, and steady-state native-only activation
does not start or stop roscore. During a transition from an older ROS1 release,
obsolete installed or still-active bridge units are explicitly stopped and
disabled, including loaded units whose files have disappeared. Existing
camera/TimeSync/rootfs-MID360 retirement and calibration migration hooks remain.
ROS2 factory activation now uses those same hooks.
Activation preserves the existing TimeSync serial/PPS/transport settings,
including `ORBVI_TIMESYNC_PORT` and `ORBVI_TIMESYNC_GPIO_LINE`. ROS2 deb removal
uses a service list materialized from the common helper at package build time;
it remains usable after OTA prunes the original factory release directory.

Native-only/ROS2 health checks do not source Noetic, invoke a ROS1 validator,
query rostopic or check roscore health. They check native services, local IPC
presence, configuration, product ownership and SDK HTTP reachability. Required
bounded data probes additionally receive four real camera images, TimeSync IMU
and the selected optimized localization output. Strict 4VL selects Livo pose
and additionally requires actual Livox pointcloud and IMU; neither can be
replaced by the other healthy streams. ROS2 probes receive the corresponding
DDS messages with exactly one publisher per required topic. Missing, invalid,
stale or non-advancing data fails the hook and blocks OTA commit/pruning.
Unknown product identities remain required/unverified failures. There is no
bypass switch. ROS1 keeps its existing topic/validator checks. The 4VL probe
has container IPC/TCP/DDS validation only; 4VL hardware acceptance remains
outstanding. See the source `scripts/package/health-probe/README.md` for bounds
and build/test details; socket presence alone is not data acceptance.

Development headers, static archives, CMake/pkg-config exports, examples,
smoke tools and dataset launch/configuration files are excluded. Build an
SDK from the original native install tree when developing a ROS bridge.

Factory installation is managed by the deb maintainer scripts; subsequent
application updates use the ORBVI OTA flow. Do not run dataset launch files
or copy a development workspace over this release directory.

Per-device calibration uses the SDK calibration package API and
`scripts/calibration_install.py`, independently of application OTA. Factory and
OTA payloads do not contain per-device calibration. The packaged
`orbvi_calibration_recover.service` restores interrupted transactions before
native consumers start; 4V VINS remains gated between its camera package and
VINS supplement. Recovery is a hard dependency of consumers, while the SDK
control plane uses `Wants` so diagnostics remain available when recovery fails.
Python 3 is a factory runtime dependency. Every RK3588 payload, including `ros1`,
contains `lib/orbvi_health/orbvi_native_health_probe`; build the source health-probe
package before assembly. The source contract is
`docs/orbvi/calibration-package-install.md`.

Installation validates the native camera profile and the applicable VINS or
Omni-LIVO configuration, checks services that need restoration are active, and
compares SDK camera/LiDAR hashes plus `/v1/calibration/installed` collection
readback. For 4VL, the current `--validate-only` invocation must report matching
`[Native calibration]` SHA-256 values for the three sources Omni-LIVO actually
loads: `camera_config.yaml`, `cam0_multi_calib_result.txt`, and `lidar_imu.json`.
All other package files are still checked individually. Historic journal lines
cannot satisfy this check. A stationary factory install does not require an
optimized pose within 20 seconds. Set `ORBVI_CALIBRATION_HEALTH_PROBE=true`
explicitly to add the existing native pose/stream probe.

The installer invokes native configuration tools, validators, and the optional
health probe with the current release's `lib` prepended to their child process
`LD_LIBRARY_PATH`, preserving any existing library search paths. This also
resolves transitive private libraries when the transient worker does not inherit
the SDK service's unit environment. The parent environment, `systemctl`, and
`curl` receive no installer-added library path.

The transaction persists the originally active service set and restores it on
success or rollback; manually stopped Omni-LIVO and adapters stay stopped.
The camera package records whether VINS was running before it became pending;
the supplement resumes VINS only when that intent or the current active set
requires it. Configuration readiness does not imply localization is running.
SDK control-plane and ROS bridge restoration ignore dependency activation only
for units in the saved active set, preventing their `Wants` lists from starting
previously stopped producers such as HSNet. Native consumers start normally and
keep their recovery and hardware dependencies. Boot recovery restores files and leaves
consumer startup to normal systemd ordering. Stop commands use finite unit
`TimeoutStopUSec` values, at least the default 90 seconds per service plus a
margin, with a 1800-second aggregate ceiling.

An accepted operation records its dispatch time. A retried prepare refreshes
that time; a stale absent worker can be failed through `fail-dispatch
--min-accepted-age-ms 30000`. The helper rechecks the age and state under the
transaction lock and cannot cancel an applying operation.

Package validation rejects nonfinite master JSON numbers, including exponent
overflow such as `1e400`, before staging or stopping services. Persisted state
and inspection output also reject NaN / Infinity.
