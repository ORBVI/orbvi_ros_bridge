# orbvi_ros_adapter synchronization metadata for one matched four-fisheye camera group.
# The single authoritative /rk_cam/sync_info topic accompanies both raw BGR8
# images and rectified stereo images.
# header.stamp is the canonical group stamp Tg shared by the image topics.
# raw_stamp and offset_us are indexed by physical fisheye camera:
#   0 front, 1 right, 2 rear, 3 left
# offset_us[c] = raw_stamp[c] - header.stamp.
std_msgs/Header header
uint8 TIMESTAMP_DOMAIN_UNKNOWN=0
uint8 TIMESTAMP_DOMAIN_MONOTONIC=1
uint8 TIMESTAMP_DOMAIN_REALTIME=2
uint8 TIMESTAMP_DOMAIN_SENSOR=3
uint8 timestamp_domain
uint32 sync_seq
uint8 sync_seq_source
uint64 trigger_monotonic_ns
bool trigger_seq_valid
uint32 trigger_seq
time[4] raw_stamp
int32[4] offset_us
