__constant sampler_t kPanoramaSampler =
    CLK_NORMALIZED_COORDS_FALSE | CLK_ADDRESS_CLAMP_TO_EDGE |
    CLK_FILTER_LINEAR;

float4 panorama_sample_nv12(read_only image2d_t y_plane,
                            read_only image2d_t uv_plane,
                            float2 source_xy) {
  const float y =
      read_imagef(y_plane, kPanoramaSampler, source_xy).x;
  const float2 uv = read_imagef(
      uv_plane, kPanoramaSampler,
      (float2)(source_xy.x * 0.5f, source_xy.y * 0.5f)).xy;
  return (float4)(y, uv.x, uv.y, 1.0f);
}

__kernel void panorama_nv12(
    read_only image2d_t cam_front_y,
    read_only image2d_t cam_front_uv,
    read_only image2d_t cam_right_y,
    read_only image2d_t cam_right_uv,
    read_only image2d_t cam_rear_y,
    read_only image2d_t cam_rear_uv,
    read_only image2d_t cam_left_y,
    read_only image2d_t cam_left_uv,
    __global const float* primary_x,
    __global const float* primary_y,
    __global const float* secondary_x,
    __global const float* secondary_y,
    __global const float* primary_weight,
    __global const uchar* primary_camera_slot,
    __global const uchar* secondary_camera_slot,
    write_only image2d_t dst_y,
    write_only image2d_t dst_uv,
    int dst_width,
    int dst_height) {
  const int u = get_global_id(0);
  const int v = get_global_id(1);
  if (u >= dst_width || v >= dst_height) {
    return;
  }

  const int index = v * dst_width + u;
  const uchar primary_slot = primary_camera_slot[index];
  const uchar secondary_slot = secondary_camera_slot[index];
  const float2 primary_xy =
      (float2)(primary_x[index] + 0.5f, primary_y[index] + 0.5f);
  const float2 secondary_xy =
      (float2)(secondary_x[index] + 0.5f, secondary_y[index] + 0.5f);

  float4 primary = (float4)(0.0f, 0.5f, 0.5f, 1.0f);
  float4 secondary = primary;
  switch (primary_slot) {
    case 0:
      primary = panorama_sample_nv12(
          cam_front_y, cam_front_uv, primary_xy);
      break;
    case 1:
      primary = panorama_sample_nv12(
          cam_right_y, cam_right_uv, primary_xy);
      break;
    case 2:
      primary = panorama_sample_nv12(
          cam_rear_y, cam_rear_uv, primary_xy);
      break;
    case 3:
      primary = panorama_sample_nv12(
          cam_left_y, cam_left_uv, primary_xy);
      break;
    default:
      break;
  }
  switch (secondary_slot) {
    case 0:
      secondary = panorama_sample_nv12(
          cam_front_y, cam_front_uv, secondary_xy);
      break;
    case 1:
      secondary = panorama_sample_nv12(
          cam_right_y, cam_right_uv, secondary_xy);
      break;
    case 2:
      secondary = panorama_sample_nv12(
          cam_rear_y, cam_rear_uv, secondary_xy);
      break;
    case 3:
      secondary = panorama_sample_nv12(
          cam_left_y, cam_left_uv, secondary_xy);
      break;
    default:
      secondary = primary;
      break;
  }

  const float weight = clamp(primary_weight[index], 0.0f, 1.0f);
  const float4 yuv = mix(secondary, primary, weight);
  write_imagef(dst_y, (int2)(u, v),
               (float4)(yuv.x, 0.0f, 0.0f, 1.0f));
  if ((u & 1) == 0 && (v & 1) == 0) {
    write_imagef(dst_uv, (int2)(u / 2, v / 2),
                 (float4)(yuv.y, yuv.z, 0.0f, 1.0f));
  }
}
