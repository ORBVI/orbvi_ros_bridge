#!/usr/bin/env python3
import hashlib, json, os, pathlib, sys
release = pathlib.Path(sys.argv[1])
defaults = (release / 'etc/default/orbvi').read_bytes()
if b'\0' in defaults:
    raise SystemExit('fixed 4VL environment contains a NUL byte')
root = pathlib.Path('/var/lib/board-calib')
root.mkdir(parents=True, exist_ok=True)
seeds = release / 'share/factory-4vl-defaults'
manifest = json.loads((seeds / 'manifest.json').read_text())
for relative, metadata in manifest.items():
    data = (seeds / relative).read_bytes()
    if hashlib.sha256(data).hexdigest() != metadata['sha256']:
        raise SystemExit('invalid factory default checksum: ' + relative)
    destination = root / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_symlink():
        raise SystemExit('refusing a calibration symlink: ' + relative)
    try:
        fd = os.open(str(destination), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    except FileExistsError:
        if not destination.is_file():
            raise SystemExit('invalid calibration destination: ' + relative)
        continue
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())
    fd = os.open(str(destination.parent), os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)
