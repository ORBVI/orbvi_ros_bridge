#!/usr/bin/env bash
set -euo pipefail

# The selected camera runtime is the only /dev/video owner.
# Restarting rkaiq while that owner is stopped clears stale analyzer state left
# by a fast service restart before V4L2 streaming starts again.
systemctl restart rkaiq_3A.service
for _ in $(seq 1 50); do
  if systemctl is-active --quiet rkaiq_3A.service; then
    exit 0
  fi
  sleep 0.1
done

echo "rkaiq_3A.service did not become active" >&2
exit 1
