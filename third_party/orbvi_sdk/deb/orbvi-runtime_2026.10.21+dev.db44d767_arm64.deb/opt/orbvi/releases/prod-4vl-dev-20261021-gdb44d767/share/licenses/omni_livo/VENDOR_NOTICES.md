# Retained Upstream Sources

Omni-LIVO retains its original attribution comments and `LICENSE`. The retired
standalone `src/fast_livo2` package is no longer built or shipped. Its original
license text is preserved verbatim as `FAST-LIVO2-LICENSE` because Omni-LIVO
contains FAST-LIVO2-derived sources. Source history remains available at cleanup
baseline `19ed53b0d27d86fc342e8f57c0874a29f14a6d54`.

`include/vikit/camera_loader.h` and `include/vikit/params_helper.h` were moved
unchanged from `src/rpg_vikit/vikit_ros/include/vikit/` at that baseline. They
retain Christian Forster's authorship notices (including the libpointmatcher_ros
origin in params_helper). The original vikit_ros manifest declared GPLv3; its
license text is retained at `../rpg_vikit/LICENSE`.

These two headers preserve the include dependency of the installed legacy
`LIVMapper.h`. They are installed under the existing Omni-LIVO include prefix;
they are not linked into native targets and do not restore a vikit_ros catkin
package or `libvikit_ros.so`. The retired package's visualization/output helper
API is no longer provided. External users of that old ROS package must keep
their prior vendor version or migrate to the native/bridge interfaces.
