#!/usr/bin/env bash
set -euo pipefail

if [ "${ORBVI_RELEASE_PROFILE:-}" != production-4vl ] ||
   [ "${ORBVI_PRODUCT:-}" != orbvi ] ||
   [ "${ORBVI_DEVICE_MODEL:-}" != orbvi-4vl ] ||
   [ "${ORBVI_HARDWARE_PROFILE:-}" != 4vl ]; then
  exit 0
fi

release_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
template="${release_root}/share/calibration/mid360_imu.json"
directory="${ORBVI_LIDAR_CALIBRATION_PATH:-/var/lib/board-calib/MID360s_Calibration}"
destination="${directory}/lidar_imu.json"

if [ -L "${destination}" ] || { [ -e "${destination}" ] && [ ! -f "${destination}" ]; }; then
  echo "MID360 calibration destination is not a regular file" >&2
  exit 1
fi
if [ -f "${destination}" ]; then
  exit 0
fi
test -s "${template}"
install -d -m 0755 "${directory}"
temporary="$(mktemp "${directory}/.lidar_imu.XXXXXX")"
trap 'rm -f "${temporary}"' EXIT
install -m 0644 "${template}" "${temporary}"
sync -f "${temporary}"
if ! ln "${temporary}" "${destination}" 2>/dev/null; then
  if [ ! -f "${destination}" ] || [ -L "${destination}" ]; then
    echo "MID360 calibration publication failed" >&2
    exit 1
  fi
fi
sync -f "${directory}"
