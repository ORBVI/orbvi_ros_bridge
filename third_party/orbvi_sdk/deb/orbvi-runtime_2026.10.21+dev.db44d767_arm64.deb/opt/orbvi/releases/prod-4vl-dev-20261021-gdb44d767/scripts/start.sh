#!/usr/bin/env bash
set -euo pipefail

release_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
systemd_src="${release_root}/lib/systemd/system"

install -d -m 0755 /etc/default /etc/systemd/system /etc/orbvi
# shellcheck source=defaults_migration.sh
source "${release_root}/scripts/defaults_migration.sh"
source "${release_root}/scripts/release_layers.sh"

if [ -f "${release_root}/etc/default/orbvi" ]; then
  backup=""
  if [ -f /etc/default/orbvi ]; then
    backup="/etc/default/orbvi.$(date +%Y%m%d%H%M%S).bak"
    cp /etc/default/orbvi "${backup}"
    reject_legacy_camera_pipeline_overrides "${backup}"
    reject_environment_driven_custom_profile "${backup}"
  fi
  install -m 0644 "${release_root}/etc/default/orbvi" /etc/default/orbvi
  if [ -n "${backup}" ]; then
    preserve_default_value ORBVI_CONTROL_BIND "${backup}"
    preserve_default_value ORBVI_CONTROL_PORT "${backup}"
    preserve_default_value ORBVI_DATA_BIND "${backup}"
    preserve_default_value ORBVI_DATA_PORT "${backup}"
    preserve_default_value ORBVI_CAMERA_CONFIG "${backup}"
    preserve_default_value ORBVI_LIDAR_CALIBRATION_PATH "${backup}"
    preserve_camera_pipeline_config "${backup}"
    # Match factory preinst: serial/PPS wiring is site configuration, not a
    # packaged default. ROS2 deb conffiles may contain these local overrides.
    for name in \
      ORBVI_TIMESYNC_PORT \
      ORBVI_TIMESYNC_BAUD_RATE \
      ORBVI_TIMESYNC_USE_PPS \
      ORBVI_TIMESYNC_GPIO_CHIP \
      ORBVI_TIMESYNC_GPIO_LINE \
      ORBVI_TIMESYNC_ANCHOR_TIMEOUT_MS \
      ORBVI_TIMESYNC_PUBLISH_RATE \
      ORBVI_TIMESYNC_HEALTH_ENDPOINT \
      ORBVI_TIMESYNC_IMU_ENDPOINT \
      ORBVI_TIMESYNC_TRIGGER_ENDPOINT \
      ORBVI_TIMESYNC_TRANSPORT_STALE_MS \
      ORBVI_TIMESYNC_RECONNECT_MS \
      ORBVI_TIMESYNC_STAMP_DOMAIN; do
      preserve_default_value "${name}" "${backup}"
    done
    preserve_default_value ORBVI_MID360_CONFIG_PATH "${backup}"
    preserve_default_value ORBVI_MID360_INTERFACE "${backup}"
    preserve_default_value ORBVI_MID360_HOST_IP "${backup}"
    preserve_default_value ORBVI_MID360_PREFIX "${backup}"
    preserve_default_value ORBVI_MID360_PTP4L_EXTRA_ARGS "${backup}"
    preserve_default_value ORBVI_MID360_PHC2SYS_EXTRA_ARGS "${backup}"
    preserve_default_value ORBVI_MID360_PTP_READY_TIMEOUT_SEC "${backup}"
    preserve_default_value ORBVI_MID360_PHC_OFFSET_THRESHOLD_NS "${backup}"
    preserve_default_value ORBVI_MID360_PTP_READY_CONSECUTIVE_SAMPLES "${backup}"
    preserve_default_value ORBVI_MID360_CLOCK_FREQ_RESET_THRESHOLD_PPB "${backup}"
  fi
fi

if [ -x "${release_root}/scripts/device_profile.sh" ]; then
  "${release_root}/scripts/device_profile.sh" /etc/default/orbvi
fi

if [ -f /etc/default/orbvi ]; then
  set -a
  # shellcheck source=/etc/default/orbvi
  source /etc/default/orbvi
  set +a
fi

systemd-run --quiet --wait --collect \
  --property=Type=oneshot \
  --property=EnvironmentFile=/etc/default/orbvi \
  --property=NoNewPrivileges=yes \
  "${release_root}/scripts/install_mid360_calibration.sh"

usb_lite_identity_allowed() {
  case "${ORBVI_RELEASE_PROFILE:-}" in
    ""|production-4v-lite|orbvi-4v-lite|4v-lite|4vlite|production-x5|orbvi-x5) ;;
    *) return 1 ;;
  esac
  case "${ORBVI_PRODUCT:-}" in
    ""|orbvi-4v-lite|orbvi-lite|orbvi-x5|x5) ;;
    *) return 1 ;;
  esac
  case "${ORBVI_DEVICE_MODEL:-}" in
    orbvi-4v-lite|orbvi-lite|orbvi-x5|x5) ;;
    *) return 1 ;;
  esac
  case "${ORBVI_HARDWARE_PROFILE:-}" in
    x5|horizon-x5|horizon_x5) ;;
    *) return 1 ;;
  esac
}

livox_4vl_identity_allowed() {
  [ "${ORBVI_RELEASE_PROFILE:-}" = "production-4vl" ] &&
    [ "${ORBVI_PRODUCT:-}" = "orbvi" ] &&
    [ "${ORBVI_DEVICE_MODEL:-}" = "orbvi-4vl" ] &&
    [ "${ORBVI_HARDWARE_PROFILE:-}" = "4vl" ]
}

retire_rootfs_mid360_time_units() {
  local interface="${ORBVI_MID360_INTERFACE:-eth0}"
  local unit
  for unit in \
    "ros-rk3588-ptp@${interface}.service" \
    "ros-rk3588-phc2sys@${interface}.service"; do
    systemctl stop "${unit}" >/dev/null 2>&1 || true
    systemctl disable --now "${unit}" >/dev/null 2>&1 || true
  done
}

retire_removed_camera_units() {
  local unit
  for unit in \
    orbvi_six_cam_capture.service \
    orbvi_fisheye_rectify.service \
    ros-rk3588-six_cam_capture.service \
    ros-rk3588-fisheye_rectify.service \
    ros-rk3588-timesync.service \
    orbvi_timesync_bridge.service \
    orbvi_camera_pipeline_legacy_bridge.service; do
    # A package upgrade can remove the unit file before this script runs while
    # the old cgroup is still alive.  Stop the loaded unit first: in that
    # state `disable --now` fails at the disable step and never stops it.
    systemctl stop "${unit}" >/dev/null 2>&1 || true
    systemctl disable --now "${unit}" >/dev/null 2>&1 || true
    rm -f \
      "/etc/systemd/system/${unit}" \
      "/etc/systemd/system/multi-user.target.wants/${unit}"
  done
  # systemd may have had to kill a retired ROS process after its unit file
  # vanished.  Remove only unreachable master registrations so the unified
  # adapter is exposed as the sole publisher immediately after an upgrade.
  if [ "${orbvi_release_bridge}" = ros1 ] && [ -x /opt/ros/noetic/bin/rosnode ]; then
    printf 'y\n' | /bin/bash -lc \
      'source /opt/ros/noetic/setup.bash && export ROS_MASTER_URI=http://127.0.0.1:11311 && exec /opt/ros/noetic/bin/rosnode cleanup' \
      >/dev/null 2>&1 || true
  fi
  # OTA's ProtectSystem=strict namespace cannot write this retired rootfs
  # file. Delegate only this fixed removal to PID 1, as with MID360 migration;
  # keep the OTA agent's /etc write boundary unchanged.
  systemd-run --quiet --wait --collect \
    --property=Type=oneshot \
    --property=NoNewPrivileges=yes \
    /bin/rm -f /etc/camera.json
}

# OTA releases copy units into /etc/systemd/system, so files from an older
# release are not removed automatically when they disappear from the payload.
retire_removed_camera_units
orbvi_retire_unselected_bridges

if [ -d "${systemd_src}" ]; then
  while IFS= read -r unit; do
    if [ -f "${systemd_src}/${unit}" ]; then
      install -m 0644 "${systemd_src}/${unit}" "/etc/systemd/system/${unit}"
    fi
  done < <(orbvi_release_services; printf '%s\n' orbvi_usb_bulk_device.service orbvi_usb_gadget.service)
fi

if [ -f "${release_root}/share/orbvi_ota_agent/config/ota_agent.yaml" ] &&
   [ ! -f /etc/orbvi/ota_agent.yaml ]; then
  install -m 0644 "${release_root}/share/orbvi_ota_agent/config/ota_agent.yaml" \
    /etc/orbvi/ota_agent.yaml
fi

"${release_root}/scripts/write_version_json.sh" \
  "${release_root}" /data/orbvi/version.json

systemctl daemon-reload
retire_rootfs_mid360_time_units
mapfile -t boot_services < <(orbvi_boot_services "${ORBVI_RELEASE_PROFILE:-production-auto}")
systemctl enable "${boot_services[@]}" >/dev/null 2>&1 || true

if usb_lite_identity_allowed; then
  if [ "${ORBVI_ENABLE_USB_DEVICE:-false}" != "true" ] ||
     [ "${ORBVI_ENABLE_USB_UVC:-false}" != "true" ] ||
     [ "${ORBVI_USB_INCLUDE_VENDOR_BULK:-false}" != "true" ]; then
    systemctl disable --now \
      orbvi_usb_bulk_device.service \
      orbvi_usb_gadget.service >/dev/null 2>&1 || true
    echo "required USB gates failed for Lite identity: ORBVI_ENABLE_USB_DEVICE, ORBVI_ENABLE_USB_UVC, and ORBVI_USB_INCLUDE_VENDOR_BULK must all be true" >&2
    exit 1
  fi
  # Only X5 Lite takes ownership of the USB gadget. RK3588 keeps BSP ADB.
  systemctl disable adbd.service >/dev/null 2>&1 || true
  systemctl enable \
    orbvi_usb_bulk_device.service \
    orbvi_usb_gadget.service
  # Camera Graph owns the open UVC video nodes. Stop both possible owners
  # before rebuilding ConfigFS so activation cannot unbind a busy UDC.
  systemctl stop \
    orbvi_camera_pipeline_native.service \
    orbvi_ros_adapter.service \
    orbvi_six_cam_capture.service || true
  systemctl restart orbvi_usb_gadget.service
else
  systemctl disable --now \
    orbvi_usb_bulk_device.service \
    orbvi_usb_gadget.service >/dev/null 2>&1 || true
fi

# Do not restart orbvi_ota_agent here: this script is run by the OTA agent.
# Keep roscore stable while dependent ROS services are restarted.
if [ "${orbvi_release_bridge}" = ros1 ]; then
  systemctl start orbvi_roscore.service
fi
systemctl stop orbvi_vins.service orbvi_omni_livo.service || true
if livox_4vl_identity_allowed; then
  if [ "${ORBVI_ENABLE_LIVOX:-true}" != "true" ] ||
     [ ! -f "${ORBVI_MID360_CONFIG_PATH:-/var/lib/board-calib/MID360s_config.json}" ]; then
    systemctl disable --now \
      orbvi_mid360_net.service \
      orbvi_mid360_ptp.service \
      orbvi_mid360_phc2sys.service \
      orbvi_mid360.service \
      orbvi_omni_livo.service >/dev/null 2>&1 || true
    echo "required MID360 gate failed for 4VL identity: ORBVI_ENABLE_LIVOX must be true and ORBVI_MID360_CONFIG_PATH must exist" >&2
    exit 1
  fi
  systemctl enable \
    orbvi_mid360_net.service \
    orbvi_mid360_ptp.service \
    orbvi_mid360_phc2sys.service \
    orbvi_mid360.service \
    orbvi_omni_livo.service
  systemctl disable --now orbvi_vins.service >/dev/null 2>&1 || true
  systemctl stop \
    orbvi_omni_livo.service \
    orbvi_mid360.service \
    orbvi_mid360_ptp.service \
    orbvi_mid360_phc2sys.service || true
  systemctl restart orbvi_mid360_net.service
  /opt/orbvi/current/scripts/prepare_mid360_phc.sh
  systemctl restart orbvi_mid360_phc2sys.service
  systemctl restart orbvi_mid360_ptp.service
  systemctl restart orbvi_mid360.service
else
  systemctl disable --now \
    orbvi_mid360_net.service \
    orbvi_mid360_ptp.service \
    orbvi_mid360_phc2sys.service \
    orbvi_mid360.service >/dev/null 2>&1 || true
  systemctl disable --now orbvi_omni_livo.service >/dev/null 2>&1 || true
  systemctl enable orbvi_vins.service
fi
systemctl restart orbvi_timesync.service || true
/opt/orbvi/current/scripts/camera_owner_switch.sh --restart-native-only
if [ "${ORBVI_HSNET_MODE:-disabled}" = "dmabuf" ]; then
  systemctl restart orbvi_hsnet_disparity.service || true
else
  systemctl stop orbvi_hsnet_disparity.service || true
fi
# A ROS-based HSNet owner from the previous release may be killed only by the
# service restart above, after the early migration cleanup has already run.
# Purge only unreachable registrations so the unified adapter is immediately
# exposed as the sole disparity publisher after an online upgrade.
if [ "${orbvi_release_bridge}" = ros1 ] && [ -x /opt/ros/noetic/bin/rosnode ]; then
  printf 'y\n' | /bin/bash -lc \
    'source /opt/ros/noetic/setup.bash && export ROS_MASTER_URI=http://127.0.0.1:11311 && exec /opt/ros/noetic/bin/rosnode cleanup' \
    >/dev/null 2>&1 || true
fi
if livox_4vl_identity_allowed; then
  systemctl restart orbvi_omni_livo.service
else
  calibration_root="${ORBVI_CALIBRATION_ROOT:-/var/lib/board-calib}"
  calibration_state="${ORBVI_CALIBRATION_STATE_DIR:-${calibration_root}/.calibration-install}"
  if "${release_root}/scripts/calibration_install.py" vins-ready \
      --root "${calibration_root}" \
      --state-dir "${calibration_state}"; then
    systemctl restart orbvi_vins.service
  else
    systemctl stop orbvi_vins.service
    echo 'VINS remains stopped: calibration is pending or its installed files changed' >&2
  fi
fi
systemctl restart orbvi_sdk_server.service
mapfile -t adapters < <(orbvi_adapter_services)
if [ "${#adapters[@]}" -gt 0 ]; then
  systemctl restart "${adapters[@]}"
fi
