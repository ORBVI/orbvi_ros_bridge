#!/usr/bin/env bash
set -euo pipefail

action="${1:---configure}"
case "${action}" in
  --configure|--restart|--restart-native-only) ;;
  *)
    echo "usage: $0 [--configure|--restart|--restart-native-only]" >&2
    exit 2
    ;;
esac

default_file="${ORBVI_DEFAULT_FILE:-/etc/default/orbvi}"
if [ -f "${default_file}" ]; then
  set -a
  # shellcheck source=/etc/default/orbvi
  source "${default_file}"
  set +a
fi

camera_service="orbvi_camera_pipeline_native.service"
source "$(dirname "${BASH_SOURCE[0]}")/release_layers.sh"
bridge_services=()
while IFS= read -r service; do
  bridge_services+=("${service}")
done < <(orbvi_adapter_services)
systemctl enable "${camera_service}" "${bridge_services[@]}" >/dev/null
if [ "${action}" != "--configure" ]; then
  # Keep Camera ownership deterministic: bring up the native owner first, then
  # reconnect the ROS metadata adapter to its MsgBus stream.
  if [ "${#bridge_services[@]}" -gt 0 ]; then
    systemctl stop "${bridge_services[@]}"
  fi
  systemctl restart "${camera_service}"
  # Full release activation leaves adapters stopped until every native source
  # and the SDK have restarted. Standalone camera restarts keep old behavior.
  if [ "${action}" = "--restart" ] && [ "${#bridge_services[@]}" -gt 0 ]; then
    systemctl restart "${bridge_services[@]}"
  fi
fi
