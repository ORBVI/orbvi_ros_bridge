VIKIT
-----

Vikit (Vision-Kit) provides some tools for your vision/robotics project.
Far from stable.

## ORBVI retained subset

Only `vikit_common` remains a native build dependency of Omni-LIVO. Its library,
installed headers and camera models are preserved. The standalone `vikit_ros`
and `vikit_py` packages were retired with FAST-LIVO2. Two ROS camera-loader
compatibility headers remain with Omni-LIVO; see `../Omni-LIVO/VENDOR_NOTICES.md`.

The imported source authors and origins remain recorded in the individual files:
Christian Forster (Vision-Kit), Christian Kerl / dvo (file reader and robust cost),
Isis Innovation / PTAM (homography and patch score), and Hauke Strasdat
(ringbuffer). `LICENSE` supplies the GPLv3 text referenced by the retained dvo
files and the former vikit_ros manifest; it does not replace the individual
files' notices or declare a new license for the entire mixed-source tree.

The source snapshot before cleanup is Git commit
`19ed53b0d27d86fc342e8f57c0874a29f14a6d54`, path `src/rpg_vikit`.
No upstream revision is invented for this historical import. Keep all per-file
attributions and permission notices when updating or redistributing the subset.
