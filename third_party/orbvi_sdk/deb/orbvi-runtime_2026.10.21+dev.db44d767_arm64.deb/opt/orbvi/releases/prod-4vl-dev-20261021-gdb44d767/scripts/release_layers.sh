#!/usr/bin/env bash
# The packaged selection is immutable; site defaults cannot change membership.
orbvi_release_bridge=ros1
if [ -f "$(dirname "${BASH_SOURCE[0]}")/release_bridge" ]; then
  read -r orbvi_release_bridge < "$(dirname "${BASH_SOURCE[0]}")/release_bridge"
fi
case "${orbvi_release_bridge}" in
  none|ros1|ros2) ;;
  *) echo "invalid release bridge: ${orbvi_release_bridge}" >&2; return 1 ;;
esac

orbvi_bridge_services() {
  case "${1:-${orbvi_release_bridge}}" in
    none) ;;
    ros1) printf '%s\n' orbvi_roscore.service orbvi_ros_adapter.service ;;
    ros2) printf '%s\n' orbvi_ros2_adapter.service ;;
    *) return 1 ;;
  esac
}

orbvi_adapter_services() {
  local service
  while IFS= read -r service; do
    [ "$service" = orbvi_roscore.service ] || printf '%s\n' "$service"
  done < <(orbvi_bridge_services "${1:-${orbvi_release_bridge}}")
}

orbvi_release_services() {
  printf '%s\n' orbvi_calibration_recover.service orbvi_ota_agent.service orbvi_timesync.service \
    orbvi_camera_pipeline_native.service orbvi_hsnet_disparity.service \
    orbvi_sdk_server.service orbvi_mid360_net.service orbvi_mid360_ptp.service \
    orbvi_mid360_phc2sys.service orbvi_mid360.service orbvi_vins.service \
    orbvi_omni_livo.service
  orbvi_bridge_services "${1:-${orbvi_release_bridge}}"
}

orbvi_boot_services() {
  local profile="$1" bridge="${2:-${orbvi_release_bridge}}"
  printf '%s\n' orbvi_calibration_recover.service orbvi_ota_agent.service orbvi_timesync.service \
    orbvi_camera_pipeline_native.service orbvi_hsnet_disparity.service \
    orbvi_sdk_server.service
  if [ "${profile}" != production-4v ]; then
    printf '%s\n' orbvi_mid360_net.service orbvi_mid360_ptp.service \
      orbvi_mid360_phc2sys.service orbvi_mid360.service
  fi
  if [ "${profile}" = production-4vl ]; then
    printf '%s\n' orbvi_omni_livo.service
  else
    printf '%s\n' orbvi_vins.service
  fi
  orbvi_bridge_services "${bridge}"
}

# Only retire installed bridges during a mode transition. Native owners have
# no reverse dependency on these units and must not be stopped here.
orbvi_retire_unselected_bridges() {
  local bridge unit
  for bridge in ros1 ros2; do
    [ "${bridge}" != "${orbvi_release_bridge}" ] || continue
    while IFS= read -r unit; do
      if [ -e "/etc/systemd/system/${unit}" ] ||
         [ -L "/etc/systemd/system/multi-user.target.wants/${unit}" ] ||
         systemctl is-active --quiet "${unit}"; then
        systemctl stop "${unit}" || true
        systemctl disable "${unit}" || true
        rm -f "/etc/systemd/system/${unit}" \
          "/etc/systemd/system/multi-user.target.wants/${unit}"
      fi
    done < <(orbvi_bridge_services "${bridge}")
  done
}
