#!/usr/bin/env python3
"""Bounded device calibration package control and durable file transaction.

The HTTP process prepares immutable input. A separate systemd unit applies it.
No solver or geometric derivation lives here; native consumers validate geometry.
"""
import argparse
import contextlib
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid

MAX_PACKAGE = 8 * 1024 * 1024
MAX_STATUS = 1024 * 1024
CAMERA = {"camera_config.yaml", "orbvi_calibration_master.json"}
VINS = {"fisheye_8s/fisheye_stereo_imu_config.yaml"} | {
    "fisheye_8s/{}{}.yaml".format(side, i) for side in ("left", "right") for i in range(4)}
LIDAR = {"MID360s_Calibration/cam{}_multi_calib_result.txt".format(i) for i in range(4)} | {
    "MID360s_Calibration/lidar_imu.json"}
TERMINAL = {"succeeded", "failed", "rolled_back"}
RUNTIME = Path(__file__).resolve().parents[1]
SERVICES = ("orbvi_camera_pipeline_native.service", "orbvi_hsnet_disparity.service",
            "orbvi_vins.service", "orbvi_omni_livo.service", "orbvi_sdk_server.service",
            "orbvi_ros_adapter.service", "orbvi_ros2_adapter.service")


def require(value, reason):
    if not value:
        raise ValueError(reason)


def load_json(text):
    def finite_number(value):
        number = float(value)
        require(math.isfinite(number), "nonfinite JSON number")
        return number

    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON field")
            result[key] = value
        return result
    return json.loads(text, object_pairs_hook=pairs,
                      parse_float=finite_number, parse_constant=finite_number)


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


def digest_manifest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def ascii_text(value, maximum=256):
    return isinstance(value, str) and 0 < len(value) <= maximum and all(32 <= ord(c) <= 126 for c in value)


def sha(value):
    return isinstance(value, str) and re.fullmatch("[0-9a-f]{64}", value) is not None


def operation(value):
    require(isinstance(value, str) and re.fullmatch("[0-9a-f]{32}([0-9a-f]{32})?", value), "invalid operation_id")
    return value


def read_json(path, default=None):
    if not path.exists():
        require(not path.is_symlink(), "invalid JSON symlink")
        return default
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_PACKAGE, "invalid JSON file")
    return load_json(path.read_text(encoding="utf-8"))


def sync_dir(path):
    fd = os.open(str(path), os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def mkdir_durable(path, mode=0o755):
    if path.exists():
        require(path.is_dir() and not path.is_symlink(), "directory is not regular")
        return
    mkdir_durable(path.parent)
    path.mkdir(mode=mode)
    sync_dir(path.parent)


def atomic_bytes(path, data, mode=0o644):
    require(not path.is_symlink(), "destination symlink")
    mkdir_durable(path.parent)
    fd, temporary = tempfile.mkstemp(prefix=".calibration-", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as output:
            output.write(data)
            output.flush()
            os.fchmod(output.fileno(), mode)
            os.fsync(output.fileno())
        os.replace(temporary, path)
        sync_dir(path.parent)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def atomic_json(path, value):
    atomic_bytes(path, encoded(value) + b"\n")


def run(args, timeout=30, env=None):
    result = subprocess.run([str(arg) for arg in args], stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=timeout, check=False, env=env)
    if result.returncode:
        raise RuntimeError("command failed: " + str(args[0]) + " " + result.stderr.decode(errors="replace")[:256])
    return result.stdout


def native_run(args, timeout=30):
    # A transient installer does not inherit the SDK unit's Environment=.
    # Native binaries need the release directory for transitive private ELF
    # dependencies as RUNPATH only applies to their direct dependencies.
    environment = dict(os.environ)
    inherited = environment.get("LD_LIBRARY_PATH", "")
    environment["LD_LIBRARY_PATH"] = str(RUNTIME / "lib") + (os.pathsep + inherited if inherited else "")
    return run(args, timeout=timeout, env=environment)


def http_json(route, ota=False):
    port = os.environ.get("ORBVI_OTA_AGENT_PORT", "8810") if ota else os.environ.get("ORBVI_CONTROL_PORT", "18088")
    host = os.environ.get("ORBVI_OTA_AGENT_HOST", "127.0.0.1") if ota else "127.0.0.1"
    require(re.fullmatch(r"[A-Za-z0-9._-]+", host), "invalid OTA agent host")
    require(port.isdigit() and 0 < int(port) < 65536, "invalid control port")
    output = run(["curl", "--fail", "--silent", "--show-error", "--max-time", "2",
                  "--max-filesize", str(MAX_STATUS), "http://" + host + ":" + port + route], timeout=3)
    require(len(output) <= MAX_STATUS, "control reply too large")
    result = load_json(output.decode("utf-8"))
    require(isinstance(result, dict), "invalid control reply")
    return result


def checkpoint(_point):
    """Durability boundary; tests replace this to simulate process termination."""


def systemd_seconds(value):
    # systemctl formats TimeoutStopUSec as a human-readable timespan on the
    # supported systemd releases; numeric microseconds also support test tools.
    if value.isdigit():
        return int(value) / 1000000
    factors = {"us": 0.000001, "ms": 0.001, "s": 1, "sec": 1,
               "min": 60, "h": 3600, "d": 86400}
    parts = re.findall(r"([0-9]+(?:\.[0-9]+)?)(us|ms|sec|min|s|h|d)", value)
    require(parts and re.sub(r"([0-9]+(?:\.[0-9]+)?)(us|ms|sec|min|s|h|d)", "", value).strip() == "",
            "service TimeoutStopUSec must be finite and bounded")
    return sum(float(number) * factors[unit] for number, unit in parts)


def model_vins_resume(manifest, previous, active_services):
    if manifest["device_model"] != "orbvi-4v":
        return False
    return ("orbvi_vins.service" in active_services or
            (previous.get("vins_state") == "pending" and previous.get("vins_resume_requested") is True))


def validate_packet(packet, sn, model):
    require(isinstance(packet, dict) and set(packet) == {"manifest", "bundle_hash", "files"}, "invalid package fields")
    require(len(encoded(packet)) <= MAX_PACKAGE, "package exceeds 8 MiB")
    manifest = packet["manifest"]
    required = {"schema_version", "device_sn", "device_model", "platform", "package_kind",
                "depends_on_camera_hash", "files"}
    require(isinstance(manifest, dict) and required <= set(manifest) <= required | {"source"}, "invalid manifest fields")
    require(ascii_text(sn) and model in ("orbvi-4v", "orbvi-4vl"), "invalid device identity")
    require(manifest["schema_version"] == "orbvi-calibration-manifest-v1" and
            manifest["platform"] == "rk3588", "unsupported calibration schema/platform")
    require(manifest["device_sn"] == sn and manifest["device_model"] == model, "device identity mismatch")
    source = manifest.get("source", {})
    require(isinstance(source, dict) and len(source) <= 64 and all(ascii_text(k) and isinstance(v, str) and
            len(v) <= 4096 and all(32 <= ord(c) <= 126 for c in v) for k, v in source.items()), "source must contain bounded ASCII strings")
    kind = manifest["package_kind"]
    expected = CAMERA if kind == "camera" else VINS if kind == "vins_supplement" else CAMERA | LIDAR if kind == "full_4vl" else None
    require(expected is not None and ((kind == "full_4vl") == (model == "orbvi-4vl")), "package kind/product mismatch")
    dependency = manifest["depends_on_camera_hash"]
    require(sha(dependency) if kind == "vins_supplement" else dependency == "", "invalid camera dependency")
    entries = manifest["files"]
    require(isinstance(entries, list) and len(entries) == len(expected), "invalid manifest file count")
    paths = []
    hashes = {}
    for entry in entries:
        require(isinstance(entry, dict) and set(entry) == {"path", "sha256"}, "invalid file entry")
        path = entry["path"]
        require(path in expected and path not in hashes and sha(entry["sha256"]), "invalid or duplicate file path/hash")
        paths.append(path)
        hashes[path] = entry["sha256"]
    require(paths == sorted(paths) and set(paths) == expected, "manifest files must be complete and sorted")
    require(sha(packet["bundle_hash"]) and digest_manifest(manifest) == packet["bundle_hash"], "bundle hash mismatch")
    contents = {}
    require(isinstance(packet["files"], list) and len(packet["files"]) == len(expected), "package file count mismatch")
    for entry in packet["files"]:
        require(isinstance(entry, dict) and set(entry) == {"path", "content"}, "invalid package file")
        path, text = entry["path"], entry["content"]
        require(path in expected and path not in contents and isinstance(text, str) and "\0" not in text, "invalid file content/path")
        contents[path] = text.encode("utf-8")
        require(hashlib.sha256(contents[path]).hexdigest() == hashes[path], "file hash mismatch")
    require(set(contents) == expected, "missing package file")
    if kind != "vins_supplement":
        require(len(contents["orbvi_calibration_master.json"]) <= 256 * 1024, "master JSON exceeds 256 KiB")
        master = load_json(contents["orbvi_calibration_master.json"].decode("utf-8"))
        require(isinstance(master, dict) and all(master.get(k) == manifest[k] for k in ("device_sn", "device_model", "platform")), "master identity mismatch")
    else:
        main = contents["fisheye_8s/fisheye_stereo_imu_config.yaml"].decode("utf-8")
        references = []
        for index in range(8):
            matches = re.findall(r"^cam" + str(index) + r"_calib\s*:\s*(?:\"([^\"]+)\"|'([^']+)'|([^\s#]+))\s*(?:#.*)?$", main, re.MULTILINE)
            require(len(matches) == 1, "VINS config requires one reference per camera")
            value = next(value for value in matches[0] if value)
            reference = PurePosixPath(value)
            require(not reference.is_absolute() and ".." not in reference.parts and "\\" not in value,
                    "VINS config reference escapes package")
            references.append(reference.as_posix())
        require(set(references) == {Path(path).name for path in VINS if path.endswith(".yaml") and "config" not in path} and
                len(set(references)) == 8, "VINS config references must name the eight packaged camera YAMLs")
    return manifest, contents


class Store:
    def __init__(self, root, state_dir=None):
        self.root = Path(root).absolute()
        self.state_dir = Path(state_dir).absolute() if state_dir else self.root / ".calibration-install"
        self.installed_path = self.root / ".calibration-install/installed.json"
        self.status_path = self.state_dir / "status.json"
        self.previous = self.state_dir / "previous"
        self.journal = self.state_dir / "journal.json"

    @contextlib.contextmanager
    def lock(self):
        require(not self.root.is_symlink() and not self.state_dir.is_symlink(), "calibration root/state symlink")
        mkdir_durable(self.state_dir, mode=0o700)
        lock_path = self.state_dir / "lock"
        require(not lock_path.is_symlink(), "lock symlink")
        with lock_path.open("a+b") as handle:
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise ValueError("calibration installation busy")
            try:
                yield
            finally:
                fcntl.flock(handle, fcntl.LOCK_UN)

    def target(self, relative):
        require(relative in CAMERA | VINS | LIDAR, "destination outside whitelist")
        target = self.root / relative
        for path in (target,) + tuple(target.parents):
            if path == self.root.parent:
                break
            require(not path.is_symlink(), "destination contains symlink")
        require(not target.exists() or target.is_file(), "destination is not regular")
        return target

    def status(self, op=None):
        latest = read_json(self.status_path)
        if latest and (op is None or latest.get("operation_id") == operation(op)):
            return latest
        path = self.state_dir / "operations" / (operation(op) + ".json") if op else self.status_path
        return read_json(path, {"known": False, "terminal": True, "success": False, "state": "unknown"})

    def save_status(self, value, state=None, message=""):
        value = dict(value)
        if state:
            value["state"] = state
        value.update(known=True, terminal=value["state"] in TERMINAL,
                     success=value["state"] == "succeeded", message=message[:512])
        atomic_json(self.state_dir / "operations" / (operation(value["operation_id"]) + ".json"), value)
        atomic_json(self.status_path, value)
        return value

    def inspect(self):
        require(not self.installed_path.parent.is_symlink(), "installed manifest directory symlink")
        installed = read_json(self.installed_path)
        if not installed:
            return {"installed": False, "state": "unmanaged", "manifest": {}, "master": None, "effective_bundle_hash": "",
                    "file_checks": [], "files_verified": False, "vins_state": "unknown"}
        manifest = installed["manifest"]
        checks = []
        for entry in manifest["files"]:
            actual, status = "", "missing"
            try:
                target = self.target(entry["path"])
                if target.is_file() and target.stat().st_size <= MAX_PACKAGE:
                    actual = hashlib.sha256(target.read_bytes()).hexdigest()
                    status = "verified" if actual == entry["sha256"] else "mismatch"
            except (ValueError, OSError):
                status = "invalid"
            checks.append({"path": entry["path"], "expected_sha256": entry["sha256"], "actual_sha256": actual,
                           "matches": status == "verified", "status": status})
        verified = bool(checks) and all(item["matches"] for item in checks) and digest_manifest(manifest) == installed["effective_bundle_hash"]
        vins = installed["vins_state"]
        master = read_json(self.target("orbvi_calibration_master.json")) if verified else None
        return {"installed": True, "manifest": manifest, "effective_bundle_hash": installed["effective_bundle_hash"],
                "master": master,
                "package_bundle_hash": installed["package_bundle_hash"], "vins_state": vins,
                "state": "invalid" if not verified else "vins_pending" if vins == "pending" else "ready",
                "files_verified": verified, "file_checks": checks}

    def vins_ready(self):
        info = self.inspect()
        return not info["installed"] or (info["files_verified"] and info["vins_state"] == "ready")

    def ota_idle(self):
        # prepare is called synchronously by the SDK HTTP handler: querying that
        # handler here would deadlock. The OTA agent is the independent authority.
        state = http_json("/v1/ota/progress", ota=True).get("state")
        require(state in ("IDLE", "DONE", "FAILED", "CANCELED"), "OTA busy or state unavailable")

    def check_dependency(self, manifest):
        if manifest["package_kind"] != "vins_supplement":
            return
        info = self.inspect()
        require(info["installed"] and info["files_verified"] and info["manifest"].get("device_sn") == manifest["device_sn"] and
                info["manifest"].get("device_model") == manifest["device_model"], "camera dependency has no verified base")
        require(hashlib.sha256(self.target("camera_config.yaml").read_bytes()).hexdigest() == manifest["depends_on_camera_hash"], "camera dependency mismatch")

    def prepare(self, packet, sn, model):
        manifest, _ = validate_packet(packet, sn, model)
        latest = self.status()
        # Applying owns the transaction lock. Idempotent observers do not need
        # that lock and cannot launch a second installer for the same operation.
        if not latest["terminal"] and latest.get("bundle_hash") == packet["bundle_hash"] and latest["state"] != "accepted":
            return dict(latest, accepted=True, dispatch_required=False)
        with self.lock():
            latest = self.status()
            if not latest["terminal"]:
                require(latest["bundle_hash"] == packet["bundle_hash"], "calibration installation busy")
                if latest["state"] == "accepted":
                    latest = self.save_status(dict(latest, accepted_at_unix_ms=int(time.time() * 1000)))
                return dict(latest, accepted=True, dispatch_required=latest["state"] == "accepted")
            if latest.get("known"):
                self.cleanup(latest["operation_id"])
            self.ota_idle()
            self.check_dependency(manifest)
            for entry in manifest["files"]:
                self.target(entry["path"])
            op = uuid.uuid4().hex
            directory = self.state_dir / "staging" / op
            atomic_json(directory / "package.json", packet)
            return dict(self.save_status({"operation_id": op, "state": "accepted", "bundle_hash": packet["bundle_hash"],
                "accepted_at_unix_ms": int(time.time() * 1000), "effective_bundle_hash": "", "device_sn": sn,
                "device_model": model, "package_kind": manifest["package_kind"]}), accepted=True, dispatch_required=True)

    def fail_dispatch(self, op, message, min_accepted_age_ms=0):
        require(isinstance(min_accepted_age_ms, int) and 0 <= min_accepted_age_ms <= 3600000, "invalid accepted age")
        try:
            with self.lock():
                value = self.status(op)
                if not value.get("known") or value["state"] != "accepted" or self.status().get("operation_id") != op:
                    return value
                if int(time.time() * 1000) - value.get("accepted_at_unix_ms", 0) < min_accepted_age_ms:
                    return value
                result = self.save_status(value, "failed", message)
                self.cleanup(op)
                return result
        except ValueError as error:
            if "busy" in str(error):
                return self.status(op)  # An applying worker owns the transaction.
            raise

    def cleanup(self, op):
        shutil.rmtree(self.previous, ignore_errors=True)
        shutil.rmtree(self.state_dir / "staging" / op, ignore_errors=True)
        require(not self.previous.exists() and not (self.state_dir / "staging" / op).exists(), "transaction cleanup incomplete")
        self.journal.unlink(missing_ok=True)
        sync_dir(self.state_dir)

    def new_installed(self, manifest, bundle_hash, active_services=()):
        previous = read_json(self.installed_path) or {}
        value = dict(manifest)
        value["schema_version"] = "orbvi-calibration-installed-v1"
        kind = manifest["package_kind"]
        if kind == "vins_supplement":
            value = dict(previous["manifest"])
            files = {entry["path"]: entry for entry in value["files"]}
            files.update({entry["path"]: entry for entry in manifest["files"]})
            value["files"] = [files[path] for path in sorted(files)]
            value["supplement_bundle_hash"] = bundle_hash
            value["supplement_source"] = manifest.get("source", {})
            vins = "ready"
        else:
            value["base_bundle_hash"] = bundle_hash
            value["supplement_bundle_hash"] = ""
            vins = "pending" if kind == "camera" else "not_applicable"
        value["vins_state"] = vins
        return {"manifest": value, "effective_bundle_hash": digest_manifest(value),
                "package_bundle_hash": bundle_hash, "vins_state": vins,
                "vins_resume_requested": model_vins_resume(manifest, previous, active_services)}

    def backup(self, contents):
        require(not self.previous.exists(), "unfinished previous backup")
        mkdir_durable(self.previous, mode=0o700)
        records = []
        for relative in sorted(contents):
            target = self.target(relative)
            existed = target.exists()
            records.append({"path": relative, "existed": existed})
            if existed:
                require(target.stat().st_size <= MAX_PACKAGE, "previous calibration file exceeds limit")
                atomic_bytes(self.previous / "files" / relative, target.read_bytes())
        old = read_json(self.installed_path)
        atomic_json(self.previous / "installed.json", old)
        atomic_json(self.journal, {"files": records, "backup_ready": True})
        checkpoint("backup_ready")

    def rollback_files(self):
        journal = read_json(self.journal)
        if not journal or not journal.get("backup_ready"):
            return
        for entry in journal["files"]:
            target = self.target(entry["path"])
            if entry["existed"]:
                atomic_bytes(target, (self.previous / "files" / entry["path"]).read_bytes())
            elif target.exists():
                target.unlink()
                sync_dir(target.parent)
        old = read_json(self.previous / "installed.json")
        if old:
            atomic_json(self.installed_path, old)
        elif self.installed_path.exists():
            self.installed_path.unlink()
            sync_dir(self.installed_path.parent)

    def stop_services(self):
        bridge = self.bridge()
        adapters = ["orbvi_ros_adapter.service"] if bridge == "ros1" else ["orbvi_ros2_adapter.service"] if bridge == "ros2" else []
        services = adapters + ["orbvi_vins.service", "orbvi_omni_livo.service",
             "orbvi_hsnet_disparity.service", "orbvi_sdk_server.service", "orbvi_camera_pipeline_native.service"]
        # A stop transaction may follow dependency order; budget the sum rather
        # than timing out at Python's unrelated default of 30 seconds.
        budget = 15
        for service in services:
            configured = run(["systemctl", "show", "--property=TimeoutStopUSec", "--value", service], timeout=5)
            budget += max(90, systemd_seconds(configured.decode().strip()))
        require(budget <= 1800, "service stop timeout budget exceeds 1800 seconds")
        run(["systemctl", "stop"] + services, timeout=budget)

    def bridge(self):
        bridge_file = RUNTIME / "scripts/release_bridge"
        bridge = bridge_file.read_text().strip() if bridge_file.exists() else "ros1"
        require(bridge in ("none", "ros1", "ros2"), "invalid release bridge")
        return bridge

    def active_services(self):
        active = []
        for service in SERVICES:
            try:
                run(["systemctl", "is-active", "--quiet", service], timeout=5)
                active.append(service)
            except RuntimeError:
                pass  # Inactive and absent optional units must remain stopped.
        return active

    def restore_services(self, active, installed=None):
        require(isinstance(active, list) and set(active) <= set(SERVICES), "invalid active service snapshot")
        selected = set(active)
        if installed:
            if installed["vins_state"] != "ready":
                selected.discard("orbvi_vins.service")
            elif installed.get("vins_resume_requested"):
                selected.add("orbvi_vins.service")
        errors = []
        for service in SERVICES:
            if service not in selected:
                continue
            # Control and bridge units must not use their Wants= to start
            # producers deliberately stopped before install. Only restore
            # these units when they were already active; native consumers
            # retain their recovery and hardware dependencies.
            try:
                if service in {"orbvi_sdk_server.service", "orbvi_ros_adapter.service", "orbvi_ros2_adapter.service"}:
                    run(["systemctl", "--job-mode=ignore-dependencies", "start", service], timeout=120)
                else:
                    run(["systemctl", "start", service], timeout=120)
            except Exception as error:
                errors.append(str(error))
        require(not errors, "service restoration failed: " + "; ".join(errors))
        return sorted(selected)

    def camera_profile(self):
        return os.environ.get("ORBVI_CAMERA_PIPELINE_CONFIG", str(RUNTIME / "share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588.yaml"))

    def verify_vins_path(self):
        profile = self.camera_profile()
        output = native_run([RUNTIME / "lib/orbvi_camera_pipeline_runtime/camera_pipeline_configctl", "--config", profile, "--get", "vins.config_path"])
        path = Path(output.decode("utf-8").strip())
        expected = self.root / "fisheye_8s/fisheye_stereo_imu_config.yaml"
        require(path.is_absolute() and path.resolve() == expected.resolve(), "VINS profile config path differs from installed package")

    def verify_native(self, model, info):
        configctl = RUNTIME / "lib/orbvi_camera_pipeline_runtime/camera_pipeline_configctl"
        native_run([configctl, "--config", self.camera_profile(), "--validate"])
        if model == "orbvi-4vl":
            camera = Path(os.environ.get("ORBVI_CALIBRATION_PATH", str(self.root / "camera_config.yaml")))
            lidar = Path(os.environ.get("ORBVI_LIDAR_CALIBRATION_PATH", str(self.root / "MID360s_Calibration")))
            require(camera.resolve() == self.target("camera_config.yaml").resolve() and
                    lidar.resolve() == (self.root / "MID360s_Calibration").resolve(), "native calibration path differs from installed package")
            output = native_run([RUNTIME / "lib/omni_livo/omni_livo_native_node",
                "--config=" + str(RUNTIME / "share/omni_livo/config/mid360_native.yaml"),
                "--board-camera-config=" + str(camera), "--lidar-calibration-dir=" + str(lidar),
                "--validate-only"], timeout=30)
            observed = {}
            for path, checksum in re.findall(r"^\[Native calibration\] source=(.+) sha256=([0-9a-f]{64})$",
                                              output.decode("utf-8"), re.MULTILINE):
                observed[str(Path(path).resolve())] = checksum
            for entry in info["manifest"]["files"]:
                # Omni derives the other camera anchors from the rig; its
                # actual native source list contains precisely these files.
                if entry["path"] in {"camera_config.yaml", "MID360s_Calibration/cam0_multi_calib_result.txt",
                                     "MID360s_Calibration/lidar_imu.json"}:
                    require(observed.get(str(self.target(entry["path"]).resolve())) == entry["sha256"],
                            "native calibration loaded SHA-256 differs from package: " + entry["path"])
        elif info["vins_state"] == "ready":
            self.verify_vins_path()
            gray = native_run([configctl, "--config", self.camera_profile(), "--get", "vins.gray_socket_path"]).decode().strip()
            native_run([RUNTIME / "lib/vins/vins_native_node", "--config", self.root / "fisheye_8s/fisheye_stereo_imu_config.yaml",
                 "--gray-socket", gray, "--validate-only"], timeout=30)

    def verify(self, model, active_services=None):
        info = self.inspect()
        require(info["files_verified"], "installed file verification failed")
        self.verify_native(model, info)
        for service in active_services or []:
            run(["systemctl", "is-active", "--quiet", service], timeout=5)
        expected = next(entry["sha256"] for entry in info["manifest"]["files"] if entry["path"] == "camera_config.yaml")
        deadline = time.monotonic() + 20
        while True:
            try:
                observed = http_json("/v1/calibration")
                require(observed.get("status") == "READY" and observed.get("calibration_hash") == expected, "camera readback mismatch")
                if model == "orbvi-4vl":
                    lidar = observed.get("lidar_calibration", {})
                    require(lidar.get("status") == "READY", "LiDAR calibration is not READY")
                    require(observed.get("lidar_imu_extrinsics_status") == "READY" and
                            observed.get("lidar_imu_extrinsics_available") is True,
                            "manufacturer LiDAR IMU calibration is not READY")
                    names = ["cam{}_multi_calib_result.txt".format(i) for i in range(4)] + ["lidar_imu.json"]
                    data = b"ORBVI_LIDAR_CALIBRATION_BUNDLE_V1"
                    for name in names:
                        value = self.target("MID360s_Calibration/" + name).read_bytes()
                        data += (":" + name + ":" + str(len(value)) + ":").encode() + value
                    require(lidar.get("lidar_calibration_hash") == hashlib.sha256(data).hexdigest(), "LiDAR readback mismatch")
                collection = http_json("/v1/calibration/installed").get("installed_calibration", {})
                require(collection.get("files_verified") is True and
                        collection.get("effective_bundle_hash") == info["effective_bundle_hash"],
                        "installed collection readback mismatch")
                break
            except Exception:
                if time.monotonic() >= deadline:
                    raise
                time.sleep(0.2)
        if os.environ.get("ORBVI_CALIBRATION_HEALTH_PROBE", "false") == "true":
            command = [RUNTIME / "lib/orbvi_health/orbvi_native_health_probe", "--profile", "production-4vl" if model == "orbvi-4vl" else "production-4v"]
            if info["vins_state"] == "pending":
                command.append("--uncalibrated")
            native_run(command, timeout=20)

    def apply(self, op):
        operation(op)
        with self.lock():
            value = self.status(op)
            require(value.get("known") and self.status().get("operation_id") == op, "unknown operation")
            if value["terminal"]:
                return value
            require(value["state"] == "accepted", "operation already started; recovery required")
            mutated = False
            stopped = False
            committed = False
            try:
                packet = read_json(self.state_dir / "staging" / op / "package.json")
                manifest, contents = validate_packet(packet, value["device_sn"], value["device_model"])
                device = http_json("/v1/device/info")
                active_sn = device.get("active_device_sn", device.get("device_sn"))
                require(active_sn == value["device_sn"] and device.get("device_model") == value["device_model"], "current device identity mismatch")
                self.ota_idle()
                self.check_dependency(manifest)
                if manifest["package_kind"] == "vins_supplement":
                    self.verify_vins_path()
                value = self.save_status(dict(value, active_services=self.active_services()), "applying")
                self.backup(contents)
                stopped = True
                self.stop_services()
                mutated = True
                for relative in sorted(contents):
                    atomic_bytes(self.target(relative), contents[relative])
                    checkpoint("published:" + relative)
                installed = self.new_installed(manifest, packet["bundle_hash"], value["active_services"])
                atomic_json(self.installed_path, installed)
                value = self.save_status(dict(value, effective_bundle_hash=installed["effective_bundle_hash"]), "verifying")
                checkpoint("verifying")
                restored = self.restore_services(value["active_services"], installed)
                self.verify(value["device_model"], restored)
                result = self.save_status(value, "succeeded", "VINS_PENDING" if installed["vins_state"] == "pending" else "installed and verified")
                committed = True
                checkpoint("committed")
                self.cleanup(op)
                return result
            except Exception as error:
                if committed:
                    return self.save_status(dict(value, cleanup_pending=True), "succeeded", "installed; cleanup pending: " + str(error))
                try:
                    if mutated:
                        self.stop_services()
                        self.rollback_files()
                    if stopped:
                        self.restore_services(value["active_services"])
                except Exception as recovery_error:
                    # Keep journal/backup intact. Boot recovery runs before any
                    # consumer and can repeat the file restoration idempotently.
                    return self.save_status(value, "recovery_required", str(error) + "; rollback: " + str(recovery_error))
                result = self.save_status(value, "rolled_back" if mutated else "failed", str(error))
                self.cleanup(op)
                return result

    def recover(self):
        if not self.state_dir.exists():
            return {"state": "clean", "terminal": True}
        try:
            with self.lock():
                value = self.status()
                if not value.get("known"):
                    return {"state": "clean", "terminal": True}
                if value["terminal"]:
                    self.cleanup(value["operation_id"])
                    return value
                self.rollback_files()
                result = self.save_status(value, "rolled_back", "interrupted transaction recovered before consumers start")
                self.cleanup(value["operation_id"])
                return result
        except ValueError as error:
            if "busy" in str(error):
                return {"state": "live_operation", "terminal": False}
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "apply", "status", "inspect", "recover", "vins-ready", "fail-dispatch"))
    parser.add_argument("--root", default="/var/lib/board-calib")
    parser.add_argument("--state-dir", help="transaction state directory; defaults to ROOT/.calibration-install")
    parser.add_argument("--device-sn")
    parser.add_argument("--model")
    parser.add_argument("--operation-id")
    parser.add_argument("--message", default="dispatch failed")
    parser.add_argument("--min-accepted-age-ms", type=int, default=0)
    args = parser.parse_args()
    store = Store(args.root, args.state_dir)
    try:
        if args.command == "prepare":
            raw = sys.stdin.buffer.read(MAX_PACKAGE + 1)
            require(len(raw) <= MAX_PACKAGE, "package exceeds 8 MiB")
            result = store.prepare(load_json(raw.decode("utf-8")), args.device_sn, args.model)
        elif args.command == "apply":
            result = store.apply(args.operation_id)
        elif args.command == "status":
            result = store.status(args.operation_id)
        elif args.command == "inspect":
            result = store.inspect()
        elif args.command == "recover":
            result = store.recover()
        elif args.command == "vins-ready":
            return 0 if store.vins_ready() else 1
        else:
            result = store.fail_dispatch(args.operation_id, args.message, args.min_accepted_age_ms)
        print(json.dumps(result, sort_keys=True, ensure_ascii=False, allow_nan=False))
        return 1 if args.command == "apply" and not result.get("success") else 0
    except Exception as error:
        print(json.dumps({"accepted": False, "error": str(error)[:512]}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
