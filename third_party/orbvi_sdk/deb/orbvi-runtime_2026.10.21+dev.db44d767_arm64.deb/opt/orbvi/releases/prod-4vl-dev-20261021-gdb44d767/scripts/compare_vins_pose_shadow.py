#!/usr/bin/env python3
"""Compare legacy VINS ROS outputs with the Phase-A shadow bridge outputs.

The pairing key is the source ``header.stamp`` nanosecond value.  Arrival time
is used only to expire bounded pending entries; it is never used as a fallback
pairing key or as a replacement for the source timestamp.
"""

from __future__ import print_function

import argparse
import collections
import sys
import threading
import time

try:
    import rospy
    from nav_msgs.msg import Odometry
    from tf2_msgs.msg import TFMessage
except ImportError as exc:  # pragma: no cover - exercised on non-ROS hosts.
    rospy = None
    Odometry = None
    TFMessage = None
    _ROS_IMPORT_ERROR = exc


LEGACY_POSE_PREFIX = "/orbvi"
SHADOW_POSE_PREFIX = "/orbvi/vins_bridge_shadow"
POSE_KINDS = (
    "imu_propagate",
    "odometry",
    "camera_pose",
    "keyframe_pose",
    "extrinsic",
)


def _max_abs(values_a, values_b):
    if len(values_a) != len(values_b):
        raise ValueError("comparison vectors have different lengths")
    if not values_a:
        return 0.0
    return max(abs(float(a) - float(b)) for a, b in zip(values_a, values_b))


def _odometry_errors(legacy, shadow):
    return {
        "position": _max_abs(
            (legacy.pose.pose.position.x,
             legacy.pose.pose.position.y,
             legacy.pose.pose.position.z),
            (shadow.pose.pose.position.x,
             shadow.pose.pose.position.y,
             shadow.pose.pose.position.z),
        ),
        "orientation": _max_abs(
            (legacy.pose.pose.orientation.x,
             legacy.pose.pose.orientation.y,
             legacy.pose.pose.orientation.z,
             legacy.pose.pose.orientation.w),
            (shadow.pose.pose.orientation.x,
             shadow.pose.pose.orientation.y,
             shadow.pose.pose.orientation.z,
             shadow.pose.pose.orientation.w),
        ),
        "twist": _max_abs(
            (legacy.twist.twist.linear.x,
             legacy.twist.twist.linear.y,
             legacy.twist.twist.linear.z,
             legacy.twist.twist.angular.x,
             legacy.twist.twist.angular.y,
             legacy.twist.twist.angular.z),
            (shadow.twist.twist.linear.x,
             shadow.twist.twist.linear.y,
             shadow.twist.twist.linear.z,
             shadow.twist.twist.angular.x,
             shadow.twist.twist.angular.y,
             shadow.twist.twist.angular.z),
        ),
        "pose_covariance": _max_abs(
            legacy.pose.covariance, shadow.pose.covariance
        ),
        "twist_covariance": _max_abs(
            legacy.twist.covariance, shadow.twist.covariance
        ),
    }


def _transform_errors(legacy, shadow):
    return {
        "translation": _max_abs(
            (legacy.transform.translation.x,
             legacy.transform.translation.y,
             legacy.transform.translation.z),
            (shadow.transform.translation.x,
             shadow.transform.translation.y,
             shadow.transform.translation.z),
        ),
        "quaternion": _max_abs(
            (legacy.transform.rotation.x,
             legacy.transform.rotation.y,
             legacy.transform.rotation.z,
             legacy.transform.rotation.w),
            (shadow.transform.rotation.x,
             shadow.transform.rotation.y,
             shadow.transform.rotation.z,
             shadow.transform.rotation.w),
        ),
    }


class CallbackGate(object):
    """Stop new callbacks and wait for callbacks already in flight."""

    def __init__(self):
        self._condition = threading.Condition()
        self._accept = True
        self._active = 0

    def enter(self):
        with self._condition:
            if not self._accept:
                return False
            self._active += 1
            return True

    def leave(self):
        with self._condition:
            self._active -= 1
            if self._active == 0:
                self._condition.notify_all()

    def close_and_wait(self):
        with self._condition:
            self._accept = False
            while self._active:
                self._condition.wait()


class PairState(object):
    """Bounded source-time pairing state for one legacy/shadow stream."""

    def __init__(self, name, max_pending, pair_wait_sec, compare_fn):
        self.name = name
        self.max_pending = max_pending
        self.pair_wait_sec = pair_wait_sec
        self.compare_fn = compare_fn
        self.pending = {"legacy": collections.OrderedDict(),
                        "shadow": collections.OrderedDict()}
        # ``rospy`` invokes subscribers from independent connection threads.
        # Keep a bounded history so a duplicate source stamp remains a
        # contract failure even after its original pair was matched.
        self.seen_stamps = {"legacy": collections.OrderedDict(),
                            "shadow": collections.OrderedDict()}
        self.received = {"legacy": 0, "shadow": 0}
        self.unmatched = {"legacy": 0, "shadow": 0}
        self.matched = 0
        self.errors = collections.OrderedDict()
        self.invalid_timestamps = 0
        self._accept_new_stamps = True
        self._lock = threading.Lock()

    def _expire(self, now):
        cutoff = now - self.pair_wait_sec
        for side in ("legacy", "shadow"):
            entries = self.pending[side]
            while entries:
                stamp, (arrival, _message) = next(iter(entries.items()))
                if arrival > cutoff:
                    break
                entries.pop(stamp)
                self.unmatched[side] += 1

    def _trim(self, side):
        entries = self.pending[side]
        while len(entries) > self.max_pending:
            entries.popitem(last=False)
            self.unmatched[side] += 1

    def _record_errors(self, errors):
        for name, value in errors.items():
            previous = self.errors.get(name, 0.0)
            self.errors[name] = max(previous, value)

    def record(self, side, message, now=None):
        if now is None:
            now = time.monotonic()
        with self._lock:
            self._expire(now)
            stamp = message.header.stamp.to_nsec()
            if stamp <= 0:
                self.received[side] += 1
                self.invalid_timestamps += 1
                self.unmatched[side] += 1
                return

            other_side = "shadow" if side == "legacy" else "legacy"
            other_entries = self.pending[other_side]
            entries = self.pending[side]
            seen = self.seen_stamps[side]
            if stamp in seen:
                # A duplicate is not allowed to consume an opposite pending
                # message.  Keep the original pending item available for its
                # valid counterpart, while recording the duplicate failure.
                self.received[side] += 1
                self.unmatched[side] += 1
                self._expire(now)
                return

            if stamp in other_entries:
                self.received[side] += 1
                seen[stamp] = None
                _arrival, other_message = other_entries.pop(stamp)
                self.matched += 1
                if side == "legacy":
                    errors = self.compare_fn(message, other_message)
                else:
                    errors = self.compare_fn(other_message, message)
                self._record_errors(errors)
            elif not self._accept_new_stamps:
                # During drain, only a source stamp already pending on the
                # opposite side may be accepted.  Tail stamps are deliberately
                # ignored and do not affect received/unmatched counters.
                self._expire(now)
                return
            else:
                self.received[side] += 1
                seen[stamp] = None
                entries[stamp] = (now, message)
                self._trim(side)

            while len(seen) > self.max_pending * 2:
                seen.popitem(last=False)
            self._expire(now)

    def begin_drain(self):
        with self._lock:
            self._accept_new_stamps = False

    def flush(self):
        with self._lock:
            for side in ("legacy", "shadow"):
                self.unmatched[side] += len(self.pending[side])
                self.pending[side].clear()

    def snapshot(self):
        with self._lock:
            return {
                "name": self.name,
                "received": dict(self.received),
                "unmatched": dict(self.unmatched),
                "matched": self.matched,
                "errors": collections.OrderedDict(self.errors),
                "invalid_timestamps": self.invalid_timestamps,
            }

    def _passed_locked(self, minimum_samples, tolerance):
        if self.received["legacy"] < minimum_samples:
            return False
        if self.received["shadow"] < minimum_samples:
            return False
        if self.matched < minimum_samples:
            return False
        if self.unmatched["legacy"] or self.unmatched["shadow"]:
            return False
        return all(value <= tolerance for value in self.errors.values())

    def passed(self, minimum_samples, tolerance):
        with self._lock:
            return self._passed_locked(minimum_samples, tolerance)

    def snapshot_and_passed(self, minimum_samples, tolerance):
        with self._lock:
            snapshot = {
                "name": self.name,
                "received": dict(self.received),
                "unmatched": dict(self.unmatched),
                "matched": self.matched,
                "errors": collections.OrderedDict(self.errors),
                "invalid_timestamps": self.invalid_timestamps,
            }
            return snapshot, self._passed_locked(minimum_samples, tolerance)


def _make_pose_states(args):
    states = collections.OrderedDict()
    for kind in POSE_KINDS:
        states[kind] = PairState(
            kind,
            args.max_pending,
            args.timestamp_pair_wait_ms / 1000.0,
            _odometry_errors,
        )
    return states


def _make_tf_states(args):
    prefix = args.shadow_frame_prefix.strip("/")
    shadow_prefix = prefix + "/" if prefix else "vins_bridge_shadow/"
    states = collections.OrderedDict((
        ("world_to_body", PairState(
            "world_to_body",
            args.max_pending,
            args.timestamp_pair_wait_ms / 1000.0,
            _transform_errors,
        )),
        ("body_to_camera", PairState(
            "body_to_camera",
            args.max_pending,
            args.timestamp_pair_wait_ms / 1000.0,
            _transform_errors,
        )),
    ))
    return states, shadow_prefix


def _tf_key(transform):
    return (transform.header.frame_id.lstrip("/"),
            transform.child_frame_id.lstrip("/"))


def _subscribe_tf(states, shadow_prefix, subscribers=None, callback_gate=None):
    if subscribers is None:
        subscribers = []
    if callback_gate is None:
        callback_gate = CallbackGate()
    targets = {
        ("world", "body"): ("legacy", "world_to_body"),
        ("body", "camera"): ("legacy", "body_to_camera"),
        (shadow_prefix + "world", shadow_prefix + "body"):
            ("shadow", "world_to_body"),
        (shadow_prefix + "body", shadow_prefix + "camera"):
            ("shadow", "body_to_camera"),
    }

    def callback(message):
        if not callback_gate.enter():
            return
        try:
            now = time.monotonic()
            for transform in message.transforms:
                target = targets.get(_tf_key(transform))
                if target is None:
                    continue
                side, name = target
                states[name].record(side, transform, now)
        finally:
            callback_gate.leave()

    subscribers.append(rospy.Subscriber(
        "/tf", TFMessage, callback,
        queue_size=500, buff_size=2 * 1024 * 1024
    ))
    return subscribers


def _subscribe_pose(states, subscribers=None, callback_gate=None):
    if subscribers is None:
        subscribers = []
    if callback_gate is None:
        callback_gate = CallbackGate()

    def make_callback(state, side):
        def callback(message):
            if not callback_gate.enter():
                return
            try:
                state.record(side, message, time.monotonic())
            finally:
                callback_gate.leave()
        return callback

    for kind, state in states.items():
        legacy_topic = LEGACY_POSE_PREFIX + "/" + kind
        shadow_topic = SHADOW_POSE_PREFIX + "/" + kind
        subscribers.append(rospy.Subscriber(
            legacy_topic, Odometry, make_callback(state, "legacy"),
            queue_size=100,
        ))
        subscribers.append(rospy.Subscriber(
            shadow_topic, Odometry, make_callback(state, "shadow"),
            queue_size=100,
        ))
    return subscribers


def _unregister_subscribers(subscribers):
    success = True
    for subscriber in reversed(subscribers):
        try:
            subscriber.unregister()
        except Exception as exc:  # pragma: no cover - rospy-specific cleanup.
            success = False
            print("subscriber unregister failed: %s" % exc, file=sys.stderr)
    return success


def _print_state(state, tolerance, minimum_samples, label):
    snapshot, passed = state.snapshot_and_passed(minimum_samples, tolerance)
    errors = " ".join(
        "max_%s=%.9g" % (name, value)
        for name, value in snapshot["errors"].items()
    )
    if not errors:
        errors = "max_error=0"
    print(
        "%s %s legacy_received=%d shadow_received=%d matched=%d "
        "legacy_unmatched=%d shadow_unmatched=%d invalid_timestamps=%d %s "
        "verdict=%s" % (
            label,
            snapshot["name"],
            snapshot["received"]["legacy"],
            snapshot["received"]["shadow"],
            snapshot["matched"],
            snapshot["unmatched"]["legacy"],
            snapshot["unmatched"]["shadow"],
            snapshot["invalid_timestamps"],
            errors,
            "PASS" if passed else "FAIL",
        )
    )
    return passed


def _validate_args(parser, args):
    if args.duration <= 0 or args.duration > 600:
        parser.error("--duration must be in (0, 600] seconds")
    if args.abs_tolerance < 0 or args.abs_tolerance > 1e3:
        parser.error("--abs-tolerance must be in [0, 1000]")
    if args.timestamp_pair_wait_ms <= 0 or args.timestamp_pair_wait_ms > 10_000:
        parser.error("--timestamp-pair-wait-ms must be in (0, 10000]")
    if args.minimum_samples <= 0 or args.minimum_samples > 100_000:
        parser.error("--minimum-samples must be in (0, 100000]")
    if args.max_pending <= 0 or args.max_pending > 100_000:
        parser.error("--max-pending must be in (0, 100000]")


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Pair legacy and VINS bridge shadow ROS outputs by source time."
    )
    parser.add_argument(
        "--duration", type=float, default=30.0,
        help="capture duration in seconds; default 30, maximum 600",
    )
    parser.add_argument(
        "--abs-tolerance", type=float, default=1e-6,
        help="maximum allowed absolute numeric error; default 1e-6",
    )
    parser.add_argument(
        "--timestamp-pair-wait-ms", "--pair-wait-ms", type=int, default=250,
        help="wall-time pending wait before counting unmatched; default 250",
    )
    parser.add_argument(
        "--minimum-samples", type=int, default=10,
        help="minimum matched samples for every pose/TF stream; default 10",
    )
    parser.add_argument(
        "--max-pending", type=int, default=2048,
        help="maximum pending source timestamps per side and stream; default 2048",
    )
    parser.add_argument(
        "--shadow-frame-prefix", default="vins_bridge_shadow",
        help="shadow TF frame prefix; default vins_bridge_shadow",
    )
    args = parser.parse_args(argv)
    _validate_args(parser, args)

    if rospy is None:
        print("VINS pose shadow comparison: FAIL (ROS import unavailable: %s)" %
              _ROS_IMPORT_ERROR, file=sys.stderr)
        return 2

    pose_states = _make_pose_states(args)
    tf_states, shadow_prefix = _make_tf_states(args)
    all_states = list(pose_states.values()) + list(tf_states.values())
    subscribers = []
    callback_gate = CallbackGate()
    unregister_ok = True
    try:
        rospy.init_node("compare_vins_pose_shadow", anonymous=True)
        _subscribe_pose(pose_states, subscribers, callback_gate)
        _subscribe_tf(tf_states, shadow_prefix, subscribers, callback_gate)
        deadline = time.monotonic() + args.duration
        rate = rospy.Rate(20)
        while not rospy.is_shutdown() and time.monotonic() < deadline:
            rate.sleep()

        # Stop accepting new source stamps at the capture boundary, but keep
        # callbacks alive for one pair-wait window so a pending opposite-side
        # stamp can still complete its pair.
        for state in all_states:
            state.begin_drain()
        drain_deadline = time.monotonic() + args.timestamp_pair_wait_ms / 1000.0
        drain_rate = rospy.Rate(20)
        while not rospy.is_shutdown() and time.monotonic() < drain_deadline:
            drain_rate.sleep()
    except (rospy.ROSInterruptException, rospy.ROSException) as exc:
        print("VINS pose shadow comparison: FAIL (ROS runtime: %s)" % exc,
              file=sys.stderr)
        return 2
    finally:
        # unregister() first; close the callback gate and wait for callbacks
        # already in flight, then flush under each PairState lock.
        unregister_ok = _unregister_subscribers(subscribers)
        callback_gate.close_and_wait()
        for state in all_states:
            state.flush()

    if not unregister_ok:
        print("VINS pose shadow comparison: FAIL (subscriber cleanup)",
              file=sys.stderr)
        return 2

    passed = True
    print("VINS pose old-vs-shadow comparison (source-time exact pairing)")
    for state in pose_states.values():
        passed = _print_state(
            state, args.abs_tolerance, args.minimum_samples, "[POSE]"
        ) and passed
    for state in tf_states.values():
        passed = _print_state(
            state, args.abs_tolerance, args.minimum_samples, "[TF]"
        ) and passed
    if passed:
        print("VINS pose old-vs-shadow comparison: PASS")
    else:
        print("VINS pose old-vs-shadow comparison: FAIL")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
