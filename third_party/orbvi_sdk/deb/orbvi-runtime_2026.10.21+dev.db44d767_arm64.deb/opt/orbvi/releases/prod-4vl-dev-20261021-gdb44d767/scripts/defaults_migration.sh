#!/usr/bin/env bash

# Functions in this file intentionally accept an output path so upgrade
# behavior can be tested without writing /etc/default/orbvi.
preserve_default_value() {
  local name="$1"
  local backup="$2"
  local output="${3:-/etc/default/orbvi}"
  local value
  [ -f "${backup}" ] || return 0
  value="$(grep -E "^${name}=" "${backup}" | tail -n 1 || true)"
  [ -n "${value}" ] || return 0
  {
    printf '\n# Preserved local override from previous /etc/default/orbvi\n'
    printf '%s\n' "${value}"
  } >> "${output}"
}

preserve_camera_pipeline_config() {
  local backup="$1"
  local output="${2:-/etc/default/orbvi}"
  local line value
  [ -f "${backup}" ] || return 0
  line="$(grep -E '^ORBVI_CAMERA_PIPELINE_CONFIG=' "${backup}" | tail -n 1 || true)"
  [ -n "${line}" ] || return 0
  value="${line#*=}"
  value="${value#\"}"
  value="${value%\"}"
  value="${value#\'}"
  value="${value%\'}"
  case "${value}" in
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime/config/camera_pipeline.yaml|\
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime/profiles/orbvi-rk3588.yaml|\
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588-non-edu.yaml|\
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588-4vl.yaml|\
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588.yaml)
      # These are historical packaged defaults, not local overrides. Keeping
      # any of these paths could point the upgraded service at a removed file.
      return 0
      ;;
  esac
  preserve_default_value ORBVI_CAMERA_PIPELINE_CONFIG "${backup}" "${output}"
}

reject_legacy_camera_pipeline_overrides() {
  local defaults="$1"
  [ -f "${defaults}" ] || return 0
  if grep -Eq \
    '^(ORBVI_CAMERA_PIPELINE_CAMERA_ORDER|ORBVI_CAMERA_PIPELINE_DEVICE_PATHS)=' \
    "${defaults}"; then
    printf '%s\n' \
      'legacy camera pipeline environment overrides are unsupported; create a complete site YAML and set ORBVI_CAMERA_PIPELINE_CONFIG' >&2
    return 1
  fi
  return 0
}

reject_environment_driven_custom_profile() {
  local defaults="$1"
  local line profile
  [ -f "${defaults}" ] || return 0
  line="$(grep -E '^ORBVI_CAMERA_PIPELINE_CONFIG=' "${defaults}" | tail -n 1 || true)"
  [ -n "${line}" ] || return 0
  profile="${line#*=}"
  profile="${profile#\"}"
  profile="${profile%\"}"
  profile="${profile#\'}"
  profile="${profile%\'}"
  case "${profile}" in
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime/config/camera_pipeline.yaml|\
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime/profiles/orbvi-rk3588.yaml|\
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588-non-edu.yaml|\
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588-4vl.yaml|\
    /opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588.yaml)
      return 0
      ;;
    /opt/orbvi/current/*)
      printf '%s\n' \
        "custom camera pipeline profile must live outside /opt/orbvi/current so upgrades cannot delete it: ${profile}" >&2
      return 1
      ;;
  esac
  if [ -f "${profile}" ] && grep -Fq '${' "${profile}"; then
    printf '%s\n' \
      "camera pipeline profile must be self-contained YAML; environment expansion is unsupported: ${profile}" >&2
    return 1
  fi
  return 0
}
