# orbvi_ros_adapter wrapper for the serialized orbvi_sdk_core::FrameSyncV2 record.
# The payload is the frozen 248-byte little-endian FrameSyncV2 wire record,
# including its CRC32. Consumers must reject any other length or invalid CRC.
uint8[] payload
