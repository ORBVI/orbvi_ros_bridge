#pragma OPENCL EXTENSION cl_khr_fp16 : enable

half clamp_to_half_pixel(float value) {
  return convert_half_rte(clamp(value, 0.0f, 255.0f));
}

__kernel void nv12_roi_to_rgb_fp16(__global const uchar* y_plane,
                                    __global const uchar* uv_plane,
                                    int y_stride,
                                    int uv_stride,
                                    int roi_x,
                                    int roi_y,
                                    int output_width,
                                    int output_height,
                                    int output_width_stride,
                                    int output_layout,
                                    int output_height_stride,
                                    __global half* output) {
  const int x = get_global_id(0);
  const int y = get_global_id(1);
  if (x >= output_width || y >= output_height) return;

  const int source_x = roi_x + x;
  const int source_y = roi_y + y;
  const float y_value = (float)y_plane[source_y * y_stride + source_x];
  const int uv_x = source_x & ~1;
  const int uv_index = (source_y / 2) * uv_stride + uv_x;
  const float u = (float)uv_plane[uv_index] - 128.0f;
  const float v = (float)uv_plane[uv_index + 1] - 128.0f;

  // BT.601 limited-range conversion, matching the current RK3588 NV12 camera
  // compatibility path. HSNet currently consumes RGB values in [0, 255].
  const float luma = fmax(y_value - 16.0f, 0.0f) * 1.16438356f;
  const half r = clamp_to_half_pixel(luma + 1.59602678f * v);
  const half g = clamp_to_half_pixel(luma - 0.39176229f * u - 0.81296764f * v);
  const half b = clamp_to_half_pixel(luma + 2.01723214f * u);

  if (output_layout == 0) {
    const int index = (y * output_width_stride + x) * 3;
    output[index] = r;
    output[index + 1] = g;
    output[index + 2] = b;
  } else {
    const int plane_size = output_width_stride * output_height_stride;
    const int index = y * output_width_stride + x;
    output[index] = r;
    output[plane_size + index] = g;
    output[2 * plane_size + index] = b;
  }
}
