#!/usr/bin/env bash
set -euo pipefail

if ! { [ "${ORBVI_RELEASE_PROFILE:-}" = "production-4vl" ] &&
       [ "${ORBVI_PRODUCT:-}" = "orbvi" ] &&
       [ "${ORBVI_DEVICE_MODEL:-}" = "orbvi-4vl" ] &&
       [ "${ORBVI_HARDWARE_PROFILE:-}" = "4vl" ]; }; then
  exit 0
fi

[ "${ORBVI_ENABLE_LIVOX:-true}" = "true" ] || exit 1

interface="${ORBVI_MID360_INTERFACE:-eth0}"
frequency_reset_threshold_ppb="${ORBVI_MID360_CLOCK_FREQ_RESET_THRESHOLD_PPB:-1000000}"
case "${frequency_reset_threshold_ppb}" in
  ""|*[!0-9]*)
    echo "invalid ORBVI_MID360_CLOCK_FREQ_RESET_THRESHOLD_PPB=${frequency_reset_threshold_ppb}" >&2
    exit 1
    ;;
esac
if [ "${frequency_reset_threshold_ppb}" -lt 1 ] ||
   [ "${frequency_reset_threshold_ppb}" -gt 100000000 ]; then
  echo "ORBVI_MID360_CLOCK_FREQ_RESET_THRESHOLD_PPB must be between 1 and 100000000" >&2
  exit 1
fi

command -v phc_ctl >/dev/null 2>&1 || {
  echo "phc_ctl is required to prepare the MID360 PHC" >&2
  exit 1
}

reset_saturated_frequency() {
  local clock="$1"
  local output frequency_ppb frequency_abs_ppb
  output="$(phc_ctl "${clock}" freq 2>&1)" || {
    printf '%s\n' "${output}" >&2
    return 1
  }
  if [[ "${output}" =~ clock\ frequency\ offset\ is\ (-?[0-9]+)(\.[0-9]+)?ppb ]]; then
    frequency_ppb="${BASH_REMATCH[1]}"
  else
    printf 'cannot parse %s frequency: %s\n' "${clock}" "${output}" >&2
    return 1
  fi
  frequency_abs_ppb="${frequency_ppb#-}"
  if [ "${frequency_abs_ppb}" -gt "${frequency_reset_threshold_ppb}" ]; then
    echo "resetting inherited saturated frequency: clock=${clock} frequency_ppb=${frequency_ppb}"
    phc_ctl "${clock}" freq 0
  fi
}

# A stopped phc2sys process leaves its last kernel frequency adjustment in
# place. Clear only implausibly large inherited corrections, preserving normal
# oscillator/NTP calibration, then seed the PHC from the product UTC clock.
reset_saturated_frequency CLOCK_REALTIME
reset_saturated_frequency "${interface}"
phc_ctl "${interface}" set
phc_ctl "${interface}" cmp
