__constant sampler_t kBevSampler =
    CLK_NORMALIZED_COORDS_FALSE | CLK_ADDRESS_CLAMP_TO_EDGE |
    CLK_FILTER_LINEAR;

float4 bev_sample_nv12(read_only image2d_t y_plane,
                       read_only image2d_t uv_plane,
                       float2 source_xy) {
  const float y =
      read_imagef(y_plane, kBevSampler, source_xy).x;
  const float2 uv = read_imagef(
      uv_plane, kBevSampler,
      (float2)(source_xy.x * 0.5f,
               source_xy.y * 0.5f)).xy;
  return (float4)(y, uv.x, uv.y, 1.0f);
}

__kernel void bev_nv12(
    read_only image2d_t cam_front_y,
    read_only image2d_t cam_front_uv,
    read_only image2d_t cam_right_y,
    read_only image2d_t cam_right_uv,
    read_only image2d_t cam_rear_y,
    read_only image2d_t cam_rear_uv,
    read_only image2d_t cam_left_y,
    read_only image2d_t cam_left_uv,
    __global const float4* map_x,
    __global const float4* map_y,
    __global const float4* map_weight,
    __global uchar* dst_nv12,
    int dst_uv_offset,
    int dst_stride,
    int dst_width,
    int dst_height) {
  const int u = get_global_id(0);
  const int v = get_global_id(1);
  if (u >= dst_width || v >= dst_height) return;

  const int index = v * dst_width + u;
  const float4 xs = map_x[index];
  const float4 ys = map_y[index];
  const float4 weights = map_weight[index];
  float4 yuv = (float4)(0.0f, 0.5f, 0.5f, 1.0f);
  float total_weight = 0.0f;

  if (weights.s0 > 0.0f) {
    const float4 sample = bev_sample_nv12(
        cam_front_y, cam_front_uv,
        (float2)(xs.s0 + 0.5f, ys.s0 + 0.5f));
    yuv.xyz += weights.s0 * (sample.xyz -
                             (float3)(0.0f, 0.5f, 0.5f));
    total_weight += weights.s0;
  }
  if (weights.s1 > 0.0f) {
    const float4 sample = bev_sample_nv12(
        cam_right_y, cam_right_uv,
        (float2)(xs.s1 + 0.5f, ys.s1 + 0.5f));
    yuv.xyz += weights.s1 * (sample.xyz -
                             (float3)(0.0f, 0.5f, 0.5f));
    total_weight += weights.s1;
  }
  if (weights.s2 > 0.0f) {
    const float4 sample = bev_sample_nv12(
        cam_rear_y, cam_rear_uv,
        (float2)(xs.s2 + 0.5f, ys.s2 + 0.5f));
    yuv.xyz += weights.s2 * (sample.xyz -
                             (float3)(0.0f, 0.5f, 0.5f));
    total_weight += weights.s2;
  }
  if (weights.s3 > 0.0f) {
    const float4 sample = bev_sample_nv12(
        cam_left_y, cam_left_uv,
        (float2)(xs.s3 + 0.5f, ys.s3 + 0.5f));
    yuv.xyz += weights.s3 * (sample.xyz -
                             (float3)(0.0f, 0.5f, 0.5f));
    total_weight += weights.s3;
  }
  if (total_weight <= 0.0f) {
    yuv = (float4)(0.0f, 0.5f, 0.5f, 1.0f);
  }

  const int output_index = v * dst_stride + u;
  dst_nv12[output_index] =
      convert_uchar_sat_rte(
          clamp(yuv.x, 0.0f, 1.0f) * 255.0f);
  if ((u & 1) == 0 && (v & 1) == 0) {
    const int uv_index =
        dst_uv_offset + (v / 2) * dst_stride + u;
    dst_nv12[uv_index] =
        convert_uchar_sat_rte(
            clamp(yuv.y, 0.0f, 1.0f) * 255.0f);
    dst_nv12[uv_index + 1] =
        convert_uchar_sat_rte(
            clamp(yuv.z, 0.0f, 1.0f) * 255.0f);
  }
}
