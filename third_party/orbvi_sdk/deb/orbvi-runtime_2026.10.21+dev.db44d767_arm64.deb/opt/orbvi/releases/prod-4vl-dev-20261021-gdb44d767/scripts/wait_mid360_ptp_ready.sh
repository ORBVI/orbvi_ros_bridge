#!/usr/bin/env bash
set -euo pipefail

if ! { [ "${ORBVI_RELEASE_PROFILE:-}" = "production-4vl" ] &&
       [ "${ORBVI_PRODUCT:-}" = "orbvi" ] &&
       [ "${ORBVI_DEVICE_MODEL:-}" = "orbvi-4vl" ] &&
       [ "${ORBVI_HARDWARE_PROFILE:-}" = "4vl" ]; }; then
  exit 0
fi

[ "${ORBVI_ENABLE_LIVOX:-true}" = "true" ] || exit 1

timeout_sec="${ORBVI_MID360_PTP_READY_TIMEOUT_SEC:-20}"
phc_offset_threshold_ns="${ORBVI_MID360_PHC_OFFSET_THRESHOLD_NS:-1000000}"
required_samples="${ORBVI_MID360_PTP_READY_CONSECUTIVE_SAMPLES:-3}"
case "${timeout_sec}" in
  ""|*[!0-9]*)
    echo "invalid ORBVI_MID360_PTP_READY_TIMEOUT_SEC=${timeout_sec}" >&2
    exit 1
    ;;
esac
if [ "${timeout_sec}" -lt 1 ] || [ "${timeout_sec}" -gt 120 ]; then
  echo "ORBVI_MID360_PTP_READY_TIMEOUT_SEC must be between 1 and 120" >&2
  exit 1
fi
case "${phc_offset_threshold_ns}" in
  ""|*[!0-9]*)
    echo "invalid ORBVI_MID360_PHC_OFFSET_THRESHOLD_NS=${phc_offset_threshold_ns}" >&2
    exit 1
    ;;
esac
if [ "${phc_offset_threshold_ns}" -lt 1 ] || [ "${phc_offset_threshold_ns}" -gt 1000000000 ]; then
  echo "ORBVI_MID360_PHC_OFFSET_THRESHOLD_NS must be between 1 and 1000000000" >&2
  exit 1
fi
case "${required_samples}" in
  ""|*[!0-9]*)
    echo "invalid ORBVI_MID360_PTP_READY_CONSECUTIVE_SAMPLES=${required_samples}" >&2
    exit 1
    ;;
esac
if [ "${required_samples}" -lt 1 ] || [ "${required_samples}" -gt 10 ]; then
  echo "ORBVI_MID360_PTP_READY_CONSECUTIVE_SAMPLES must be between 1 and 10" >&2
  exit 1
fi
command -v pmc >/dev/null 2>&1 || {
  echo "pmc is required to verify MID360 PTP readiness" >&2
  exit 1
}
command -v phc_ctl >/dev/null 2>&1 || {
  echo "phc_ctl is required to verify MID360 PHC readiness" >&2
  exit 1
}

deadline=$((SECONDS + timeout_sec))
consecutive_samples=0
last_ptp_state=unknown
last_phc_offset_ns=unknown
while [ "${SECONDS}" -lt "${deadline}" ]; do
  ptp_output="$(pmc -u -b 0 -t 0 "GET PORT_DATA_SET" 2>/dev/null || true)"
  ptp_state="$(printf '%s\n' "${ptp_output}" |
    sed -n '/portState/ {s/.*portState[[:space:]]*//; p; q;}')"
  phc_output="$(phc_ctl "${ORBVI_MID360_INTERFACE:-eth0}" cmp 2>&1 || true)"
  phc_offset_ns=unknown
  if [[ "${phc_output}" =~ offset\ from\ CLOCK_REALTIME\ is\ (-?[0-9]+)ns ]]; then
    phc_offset_ns="${BASH_REMATCH[1]}"
  fi
  phc_offset_abs_ns="${phc_offset_ns#-}"
  last_ptp_state="${ptp_state:-unknown}"
  last_phc_offset_ns="${phc_offset_ns}"

  if [ "${ptp_state}" = "MASTER" ] &&
     [ "${phc_offset_ns}" != "unknown" ] &&
     [ "${phc_offset_abs_ns}" -le "${phc_offset_threshold_ns}" ]; then
    consecutive_samples=$((consecutive_samples + 1))
    if [ "${consecutive_samples}" -ge "${required_samples}" ]; then
      echo "MID360 PTP ready: portState=${ptp_state} phc_offset_ns=${phc_offset_ns} samples=${consecutive_samples}"
      exit 0
    fi
  else
    consecutive_samples=0
  fi
  sleep 1
done

echo "MID360 PTP did not become ready within ${timeout_sec}s: portState=${last_ptp_state} phc_offset_ns=${last_phc_offset_ns} threshold_ns=${phc_offset_threshold_ns}" >&2
exit 1
