#!/usr/bin/env bash
set -euo pipefail

release_root="${1:?release root is required}"
output_path="${2:-/data/orbvi/version.json}"

release_version="$(basename "${release_root}")"
if [ -f "${release_root}/VERSION" ]; then
  release_version="$(sed -n '1p' "${release_root}/VERSION")"
fi

release_source=ota
if [ -f "${release_root}/SOURCE" ]; then
  release_source="$(sed -n '1p' "${release_root}/SOURCE")"
fi
case "${release_source}" in
  ota|factory-deb|ros2-factory-bundle|ros2-factory-deb) ;;
  *)
    echo "unsupported release source: ${release_source}" >&2
    exit 2
    ;;
esac

source_commit=""
if [ -f "${release_root}/SOURCE_COMMIT" ]; then
  source_commit="$(sed -n '1p' "${release_root}/SOURCE_COMMIT")"
fi
case "${source_commit}" in
  "") ;;
  *[!0-9a-fA-F]*)
    echo "invalid source commit: ${source_commit}" >&2
    exit 2
    ;;
esac

source_dirty_json=""
if [ -f "${release_root}/SOURCE_DIRTY" ]; then
  source_dirty="$(sed -n '1p' "${release_root}/SOURCE_DIRTY")"
  case "${source_dirty}" in
    true|false) source_dirty_json=",\"source_dirty\":\"${source_dirty}\"" ;;
    *) echo "invalid source dirty flag: ${source_dirty}" >&2; exit 2 ;;
  esac
fi

install -d -m 0755 "$(dirname "${output_path}")"
version_tmp="${output_path}.$$"
if [ -n "${source_commit}" ]; then
  printf '{"version":"%s","source":"%s","source_commit":"%s","release_profile":"%s","product":"%s","device_model":"%s","hardware_profile":"%s"%s}\n' \
    "${release_version}" \
    "${release_source}" \
    "${source_commit}" \
    "${ORBVI_RELEASE_PROFILE:-production-auto}" \
    "${ORBVI_PRODUCT:-orbvi}" \
    "${ORBVI_DEVICE_MODEL:-orbvi-family}" \
    "${ORBVI_HARDWARE_PROFILE:-auto}" "${source_dirty_json}" > "${version_tmp}"
else
  printf '{"version":"%s","source":"%s","release_profile":"%s","product":"%s","device_model":"%s","hardware_profile":"%s"%s}\n' \
    "${release_version}" \
    "${release_source}" \
    "${ORBVI_RELEASE_PROFILE:-production-auto}" \
    "${ORBVI_PRODUCT:-orbvi}" \
    "${ORBVI_DEVICE_MODEL:-orbvi-family}" \
    "${ORBVI_HARDWARE_PROFILE:-auto}" "${source_dirty_json}" > "${version_tmp}"
fi
mv "${version_tmp}" "${output_path}"
