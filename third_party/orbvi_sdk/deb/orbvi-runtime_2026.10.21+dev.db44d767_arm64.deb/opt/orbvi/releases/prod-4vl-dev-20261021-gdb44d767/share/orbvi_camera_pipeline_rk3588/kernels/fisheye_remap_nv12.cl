__constant sampler_t kRectifySampler =
    CLK_NORMALIZED_COORDS_FALSE | CLK_ADDRESS_CLAMP_TO_EDGE | CLK_FILTER_LINEAR;

float4 sample_nv12(read_only image2d_t y_plane,
                   read_only image2d_t uv_plane,
                   float2 source_xy) {
  const float y = read_imagef(y_plane, kRectifySampler, source_xy).x;
  const float2 uv = read_imagef(
      uv_plane,
      kRectifySampler,
      (float2)(source_xy.x * 0.5f, source_xy.y * 0.5f)).xy;
  return (float4)(y, uv.x, uv.y, 1.0f);
}

__kernel void fisheye_remap_nv12(read_only image2d_t cam_front_y,
                                 read_only image2d_t cam_front_uv,
                                 read_only image2d_t cam_right_y,
                                 read_only image2d_t cam_right_uv,
                                 read_only image2d_t cam_rear_y,
                                 read_only image2d_t cam_rear_uv,
                                 read_only image2d_t cam_left_y,
                                 read_only image2d_t cam_left_uv,
                                 read_only image2d_t mapx,
                                 read_only image2d_t mapy,
                                 write_only image2d_t dst_y,
                                 write_only image2d_t dst_uv,
                                 int visible_w,
                                 int visible_h,
                                 int visible_x,
                                 int visible_y,
                                 int uv_sampling_policy,
                                 int map_y_offset) {
  const int u = get_global_id(0);
  const int v = get_global_id(1);
  const int dst_w = get_image_width(dst_y);
  const int dst_h = get_image_height(dst_y);
  if (u >= dst_w || v >= dst_h) {
    return;
  }

  const int map_v = v + map_y_offset;
  const float sx = read_imagef(mapx, (int2)(u, map_v)).x;
  const float sy = read_imagef(mapy, (int2)(u, map_v)).x;
  float4 yuv = (float4)(0.0f, 0.5f, 0.5f, 1.0f);
  if (sx >= 0.0f && sx < 2.0f * (float)visible_w &&
      sy >= 0.0f && sy < 2.0f * (float)visible_h) {
    if (sy < (float)visible_h) {
      const float local_y = sy;
      if (sx < (float)visible_w) {
        yuv = sample_nv12(cam_front_y,
                          cam_front_uv,
                          (float2)(sx + (float)visible_x + 0.5f,
                                   local_y + (float)visible_y + 0.5f));
      } else {
        yuv = sample_nv12(cam_right_y,
                          cam_right_uv,
                          (float2)(sx - (float)visible_w +
                                       (float)visible_x + 0.5f,
                                   local_y + (float)visible_y + 0.5f));
      }
    } else {
      const float local_y = sy - (float)visible_h;
      if (sx < (float)visible_w) {
        yuv = sample_nv12(cam_rear_y,
                          cam_rear_uv,
                          (float2)(sx + (float)visible_x + 0.5f,
                                   local_y + (float)visible_y + 0.5f));
      } else {
        yuv = sample_nv12(cam_left_y,
                          cam_left_uv,
                          (float2)(sx - (float)visible_w +
                                       (float)visible_x + 0.5f,
                                   local_y + (float)visible_y + 0.5f));
      }
    }
  }

  write_imagef(dst_y, (int2)(u, v),
               (float4)(yuv.x, 0.0f, 0.0f, 1.0f));
  if ((u & 1) == 0 && (v & 1) == 0 && uv_sampling_policy == 0) {
    write_imagef(dst_uv,
                 (int2)(u / 2, v / 2),
                 (float4)(yuv.y, yuv.z, 0.0f, 1.0f));
  }
}
