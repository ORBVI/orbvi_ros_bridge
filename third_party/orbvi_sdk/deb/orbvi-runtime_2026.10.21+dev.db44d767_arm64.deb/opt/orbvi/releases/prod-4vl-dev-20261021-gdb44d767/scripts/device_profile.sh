#!/usr/bin/env bash
set -euo pipefail

defaults_path="${1:-/etc/default/orbvi}"

if [ -f "${defaults_path}" ]; then
  set -a
  # shellcheck source=/etc/default/orbvi
  source "${defaults_path}"
  set +a
fi

if [ "${ORBVI_DEVICE_AUTO_DETECT:-true}" != "true" ]; then
  exit 0
fi

normalize_profile() {
  local value
  value="$(printf '%s' "${1:-}" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')"
  case "${value}" in
    production-4v|orbvi-4v|4v|orbvi)
      printf '%s\n' production-4v
      ;;
    production-4vl|orbvi-4vl|4vl)
      printf '%s\n' production-4vl
      ;;
    production-auto|auto)
      printf '%s\n' production-auto
      ;;
    *)
      return 1
      ;;
  esac
}

json_string_field() {
  local file="$1"
  local key="$2"
  [ -f "${file}" ] || return 1
  sed -nE 's/.*"'"${key}"'"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/p' "${file}" | head -n 1
}

detect_from_plain_file() {
  local path="$1"
  local value
  [ -f "${path}" ] || return 1
  value="$(sed -n '1p' "${path}")"
  normalize_profile "${value}"
}

detect_from_json_file() {
  local path="$1"
  local key value
  [ -f "${path}" ] || return 1
  for key in release_profile device_model hardware_profile product; do
    value="$(json_string_field "${path}" "${key}" || true)"
    [ -n "${value}" ] || continue
    normalize_profile "${value}" && return 0
  done
  return 1
}

detect_profile() {
  local path profile
  for path in /etc/orbvi/device_profile /var/lib/board-calib/device_profile \
      /etc/orbvi/device_model /var/lib/board-calib/device_model; do
    profile="$(detect_from_plain_file "${path}" || true)"
    [ -n "${profile}" ] && [ "${profile}" != "production-auto" ] && {
      printf '%s\n' "${profile}"
      return 0
    }
  done

  for path in /etc/orbvi/device.json /var/lib/board-calib/device.json; do
    profile="$(detect_from_json_file "${path}" || true)"
    [ -n "${profile}" ] && [ "${profile}" != "production-auto" ] && {
      printf '%s\n' "${profile}"
      return 0
    }
  done

  if [ -f "${ORBVI_MID360_CONFIG_PATH:-/var/lib/board-calib/MID360s_config.json}" ]; then
    printf '%s\n' production-4vl
  else
    printf '%s\n' production-4v
  fi
}

profile="$(detect_profile)"
case "${profile}" in
  production-4v)
    product="orbvi"
    device_model="orbvi-4v"
    hardware_profile="4v"
    enable_livox="false"
    camera_pipeline_config="/opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588.yaml"
    ;;
  production-4vl)
    product="orbvi"
    device_model="orbvi-4vl"
    hardware_profile="4vl"
    enable_livox="true"
    camera_pipeline_config="/opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588-4vl.yaml"
    ;;
  *)
    echo "unsupported detected ORBVI profile: ${profile}" >&2
    exit 1
    ;;
esac

case "${ORBVI_CAMERA_PIPELINE_CONFIG:-}" in
  ""|\
  /opt/orbvi/current/share/orbvi_camera_pipeline_runtime/config/camera_pipeline.yaml|\
  /opt/orbvi/current/share/orbvi_camera_pipeline_runtime/profiles/orbvi-rk3588.yaml|\
  /opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588-non-edu.yaml|\
  /opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588-4vl.yaml|\
  /opt/orbvi/current/share/orbvi_camera_pipeline_runtime_rk3588/profiles/orbvi-rk3588.yaml)
    ;;
  *)
    camera_pipeline_config="${ORBVI_CAMERA_PIPELINE_CONFIG}"
    ;;
esac

cat >> "${defaults_path}" <<PROFILE

# Auto-detected on this board by /opt/orbvi/current/scripts/device_profile.sh.
ORBVI_RELEASE_PROFILE=${profile}
ORBVI_PRODUCT=${product}
ORBVI_DEVICE_MODEL=${device_model}
ORBVI_HARDWARE_PROFILE=${hardware_profile}
ORBVI_ENABLE_LIVOX=${enable_livox}
ORBVI_CAMERA_PIPELINE_CONFIG=${camera_pipeline_config}
ORBVI_ENABLE_USB_DEVICE=false
ORBVI_USB_INCLUDE_VENDOR_BULK=false
ORBVI_ENABLE_USB_UVC=false
ORBVI_CONTROL_INTERFACE=eth1
ORBVI_DATA_INTERFACE=eth1
PROFILE

echo "detected ORBVI device profile: ${profile} (${device_model})"
